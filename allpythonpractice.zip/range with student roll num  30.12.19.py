StudentRollNumber=range(1,1001)
for i in StudentRollNumber:
    print(i)
