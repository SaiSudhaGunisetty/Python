a=float(input("Enter first float value="))
b=float(input("Enter second float value="))
a+=b
print("After addition 'a' is:", a)
a-=b
print("After subtraction 'a' is:", a)
a*=b
print("After multiplication 'a' is:", a)
a/=b
print("After division 'a' is:", a)
a//=b
print("After floor division 'a' is:", a)
a%=b
print("After modulation 'a' is:", a)
a**=b
print("After power 'a' is:", a)



output:
Enter first float value=4.2
Enter second float value=2.1
After addition 'a' is: 6.300000000000001
After subtraction 'a' is: 4.200000000000001
After multiplication 'a' is: 8.820000000000002
After division 'a' is: 4.200000000000001
After floor division 'a' is: 2.0
After modulation 'a' is: 2.0
After power 'a' is: 4.2870938501451725

