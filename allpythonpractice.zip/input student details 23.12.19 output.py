Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=== RESTART: D:\python\GSS python Directory\input student details 23.12.19.py ==
Enter student name: Sai Sudha
Enter student address: Beeramguda
Enter mobile number: 8142601270
Enter student course: Python
Enter student Institute: Satya Technologies
******************************
STUDENT DETAILS:
******************************
Dear student your name is:  Sai Sudha
Dear student your address is:  Beeramguda
Dear student your mobile number is:  8142601270
Dear student your course is:  Python
Dear student your Institute is:  Satya Technologies
>>> 