Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
== RESTART: D:/python/GSS python Directory/range with Aadhaarcard 31.12.19.py ==
Dear customer enter your Aadhar card Number:22334455
Dear customer your Aadhaar card number is valid
>>> 