class Employee:
    CompanyName="Tech mahendra"
    CompanyAddress="Ameerpet, Hyderabad"
    CompanyWebsite="www.techmahendra.com"    
    def __init__(self,eid,ename,eaddress,edept,edesig,esalary):
        self.EmployeeID=eid
        self.EmployeeName=ename
        self.EmployeeAddress=eaddress
        self.EmployeeDepartment =edept
        self.EmployeeDesignation=edesig
        self.EmployeeSalary=esalary
    def DisplayEmployeeInformation(self):                          
        print("*"*20)
        print("EMPLOYEE INFORMATION")
        print("*"*20)
        print("Employee Company Name is", Employee.CompanyName)
        print("Employee Company Address is", Employee.CompanyAddress)
        print("Employee Company Website is", Employee.CompanyWebsite)
        print("Employee ID is", self.EmployeeID)
        print("Employee Name is", self.EmployeeName)
        print("Employee Address is", self.EmployeeAddress)
        print("Employee Deparment is", self.EmployeeDepartment)
        print("Employee Designation is", self.EmployeeDesignation)
        print("Employee Salary is", self.EmployeeSalary)
        print("*"*20)
a=input("Enter Employee ID:")
b=input("Enter Employee Name:")
c=input("Enter Employee Address:")
d =input("Enter Employee Department:")
e=input("Enter Employee Designation:")
f=float(input("Enter Employee Salary:"))
e1=Employee(a,b,c,d,e,f)
e1.DisplayEmployeeInformation()
print("*"*20)
a=input("Enter Employee ID:")
b=input("Enter Employee Name:")
c=input("Enter Employee Address:")
d =input("Enter Employee Department:")
e=input("Enter Employee Designation:")
f=float(input("Enter Employee Salary:"))
e2=Employee(a,b,c,d,e,f)
e2.DisplayEmployeeInformation()
print("*"*20)

#output
Enter Employee ID:E1122
Enter Employee Name:G.Sai Sudha
Enter Employee Address:Beeramguda
Enter Employee Department:IT
Enter Employee Designation:Python Developer
Enter Employee Salary:125000
********************
EMPLOYEE INFORMATION
********************
Employee Company Name is Tech mahendra
Employee Company Address is Ameerpet, Hyderabad
Employee Company Website is www.techmahendra.com
Employee ID is E1122
Employee Name is G.Sai Sudha
Employee Address is Beeramguda
Employee Deparment is IT
Employee Designation is Python Developer
Employee Salary is 125000.0
********************
********************
Enter Employee ID:E2233
Enter Employee Name:Noomit yagna
Enter Employee Address:Kakinada
Enter Employee Department:IT
Enter Employee Designation:Python Developer
Enter Employee Salary:100000
********************
EMPLOYEE INFORMATION
********************
Employee Company Name is Tech mahendra
Employee Company Address is Ameerpet, Hyderabad
Employee Company Website is www.techmahendra.com
Employee ID is E2233
Employee Name is Noomit yagna
Employee Address is Kakinada
Employee Deparment is IT
Employee Designation is Python Developer
Employee Salary is 100000.0
********************
********************

