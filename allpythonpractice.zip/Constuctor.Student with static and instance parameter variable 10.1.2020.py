class Student:
     CollegeName="YVU"
     Collegeaddress="Kadapa"
     Collegewebsite="www.yvu.edu"
     def __init__(self, sid, sname, scourse):
          self.StudentID=sid
          self.StudentName=sname
          self.StudentCourse=scourse
     def DisplayStudentInformation(self):
          print("~"*20)
          print("STUDENT INFORMATION")
          print("~"*20)
          print("Student college name is:", Student.CollegeName)
          print("Student collge address is:", Student.Collegeaddress)
          print("Student college website is:", Student.Collegewebsite)
          print("Student ID is:", self.StudentID)
          print("Student name is:", self.StudentName)
          print("Student course is:", self.StudentCourse)
          print("~"*20)
s1=Student('S1919', 'SAIKIRAN', 'B.tech CIVIL')
s1.DisplayStudentInformation()
print("~"*20)
s2=Student('S1019', 'SARA', 'B.tech CS')
s2.DisplayStudentInformation()

#output
~~~~~~~~~~~~~~~~~~~~
STUDENT INFORMATION
~~~~~~~~~~~~~~~~~~~~
Student college name is: YVU
Student collge address is: Kadapa
Student college website is: www.yvu.edu
Student ID is: S1919
Student name is: SAIKIRAN
Student course is: B.tech CIVIL
~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~
STUDENT INFORMATION
~~~~~~~~~~~~~~~~~~~~
Student college name is: YVU
Student collge address is: Kadapa
Student college website is: www.yvu.edu
Student ID is: S1019
Student name is: SARA
Student course is: B.tech CS
~~~~~~~~~~~~~~~~~~~~

