#BASIC PROGRAMMING-Pg:16
#Q:1
a=5
b=3
a=b
print(a)
print(b)
#output
3
3

#Q:2
a=3
b=2.5
print(a)
print(b)
#output
3
2.5

#Q:3
a=2.3
b=5
c=a+b
print(c)
#output
7.3

#Q:4
a='sathya'
b='tech'
c=a+b
print(c)
#output
sathyatech

#Q:5
a=2
b=5
c=a,b
print(c)
#output
(2,3)

#Q:6
a=2.3
b=9
a=b
print(b)
#output
9

#Q:7
a=5
b=3
c=a+b
print("sum is",c)
#output
sum is 8

#Q:8
x='a'
y=5
x=y
print(x)
print(y)
#output
7
7

#Q:9
x=2.3f
y=3
z=x+y
print(z)
#output
no output invalid syntax due to x value is alphanumeric string

#Q:10
a='x'
b='y'
c=a,b
print(c)
#output
('x', 'y')

#Q:11
x=5
y=2
z=x/y
print(z)
#output
2.5

#Q:12
x=5
y=x*x
print(y)
#output
25

#Q:13
x=3
y=x*x*x
print(y)
#output
27

#Q:14
x=3
s=x*x
c=x*x*x
print(s,c)
#output
9,27

#Q:15
x=2
s=x*x
c=x*x*x
Sum=s+c
print(Sum)
#output
12

#Q:16
x=5
y=3
z=x*y
Sum=x+y+z
print(Sum)
#output
23

#Q:17
P=1000
T=5
R=15
SI=P*T*R/100
print(SI)
#output
750.0

#Q:18
calicesdegree=60
foreignheat=calicesdegree*1.8+32
print("The foreign heat is:",foreignheat)
#output
The foreign heat is: 140.0

#Q:19
BS=10000
hra=BS*30/100
da=BS*10/100
TA=BS+hra+da
print("Total salary of employee is:",TA)
#output
Total salary of employee is: 14000.0

# Q: 20
a=60
b=70
c=80
d=a+b+c
p=d/300
Tp=p*100
print("%"%Tp)
#output
70

#Q:21
BS=10000
HRA=BS*30/100
DA=BS*10/100
GRS=BS+HRA+DA
PF=2000
PT=200
IT=BS*10/100
Deduc=PF+PT+IT
NET=GRS-Deduc
print("The gross salary of the employee is:", GRS)
print("The net salary of the employee is:",NET)
#output:
The gross salary of the employee is: 14000.0
The net salary of the employee is: 10800.0

#Q:22
P=1000
GST=P*10/100
NP=P+GST
print("The net price of the product is:", NP)
#output
The net price of the product is: 1100.0

#Q23:
NP=230
GST=30
OCP=NP-GST
print("The original price of the product is:",OCP)
#output
The original price of the product is: 200

#Q24:
NP=440
GST=(NP*10)/100
P=NP-GST
OCP=(P*100)/(100+GST)
print("The original price of the product is:",OCP)
#output:
The original price of the product is: 275.0

#TYPE CASTING Pg:22
#Q:1
fname='NoomitYagna'
lname='Nukella'
fullname=fname+lname
print(fullname)
#output
NoomitYagnaNukella

#Q:2
a=25
b=75
c=a+b
print(c)
#output
100

#Q:3
a=float(input("Enter Product-1 cost:"))
b=float(input("Enter Product-2 cost:"))
TotalBill=a+b
print("Product-1 cost is:","%d"%a)
print("Product-2 cost is:", "%d"%b)
print("--------------------------------")
print("Total Bill is:","%d"%TotalBill)
print("--------------------------------")
#output
Enter Product-1 cost: 2500
Enter Product-2 cost: 3000
Product-1 cost is: 2500
Product-2 cost is: 3000
--------------------------------
Total Bill is: 5500
--------------------------------

#Q:4
a=float(input("Enter SIM-1 cost:"))
b=float(input("Enter SIM-2 cost:"))
c=float(input("Enter SIM-3 cost:"))
d=float(input("Enter SIM-4 cost:"))
TotalBill=a+b+c+d
print("Total Bill is:",TotalBill)
#output
Enter SIM-1 cost:120
Enter SIM-2 cost:450
Enter SIM-3 cost:321
Enter SIM-4 cost:150
Total Bill is: 1041.0

#Q:5
Laptop=float(input("Enter laptop cost:"))
Discount=(Laptop*15)/100
Totalbillamt=Laptop-Discount
print("Mr Vishnu purchased laptop bill amount as:")
print("Laptop cost:", Laptop)
print("Discount amount:", Discount)
print("Total bill amount:", Totalbillamt)
#output
Enter laptop cost:62000
Mr Vishnu purchased laptop bill amount as:
Laptop cost: 62000.0
Discount amount: 9300.0
Total bill amount: 52700.0

#Q:6
package=520000
monthlysalary=package/12
print("Mr Avinash monthly salary is:","%.2f"%monthlysalary )
#output
Mr Avinash monthly salary is: 43333.33

#Q:7
products=5000
gst=products*10/100
tb=products+gst
print("Bill Amount is \t:", products)
print("Gst is\t\t:", 10,"%")
print("Gst Amount   \t:", gst)
print("-"*35)
print("Total Bill is \t:","%d"%tb)
print("-"*35)
#output
Bill Amount is 	: 5000
Gst is		: 10 %
Gst Amount   	: 500.0
-----------------------------------
Total Bill is 	: 5500
-----------------------------------

#Q:8
a=float(input("Enter 2 plates of Biryani cost:"))
b=float(input("Enter 3 plates of Manchuria cost:"))
TB=a+b
SA=TB/3
print("After sharing each person has to pay:", SA)
#output
Enter 2 plates of Biryani cost:900
Enter 3 plates of Manchuria cost:750
After sharing each person has to pay: 550.0

#Q:9
BS=float(input("Enter Lakshmi Basic salary:"))
Ta=BS*10/100
Da=BS*8/100
Hra=BS*12/100
TMS=BS+Ta+Da+Hra
print("Total monthly salary of Lakshmi is:", TMS)
#output
Enter Lakshmi Basic salary:25000
Total monthly salary of Lakshmi is: 32500.0

#Q:10
a=float(input("Prod-1 cost\t:\t"))
b=float(input("Prod-2 cost\t:\t"))
c=float(input("Prod-3 cost\t:\t"))
TB=a+b+c
Discount=TB*10/100
Finalbill=TB-Discount
print("Total Bill is\t:\t", TB)
print("Discount(10%) Amt:\t", Discount)
print("Final Bill is \t:\t", Finalbill)
print("Customer paid\t:\t", TB)
print("Balance Amt\t:\t", Discount)
#output
Prod-1 cost	: 	500.0
Prod-2 cost	:	1000.0
Prod-3 cost	: 	500.0
Total Bill is	:	 2000.0
Discount(10%) Amt:	 200.0
Final Bill is 	:	 1800.0
Customer paid	:	 2000.0
Balance Amt	:	 200.0

#Q:11
PATS=float(input("Enter project total sales amount:"))
profit=PATS*22/100
print("Anual profit of the total sales is:",profit)
#output
Enter project total sales amount:5000000
Anual profit of the total sales is: 1100000.0

#Q:12
user=int(input("Enter Total square feets of land:"))
oneacre=43560
numberofacres=user/oneacre
print("Number of acres of land:","%.2f"%numberofacres)
#output
Enter Total square feets of land:789654
Number of acres of land: 18.13

#Q:13
a=float(input("Enter item-1 price="))
b=float(input("Enter item-2 price="))
c=float(input("Enter item-3 price="))
d=float(input("Enter item-4 price="))
e=float(input("Enter item-5 price="))
subtotal=a+b+c+d+e
salestax=subtotal*7/100
TA=subtotal+salestax
print("The subtotal of the five items are:", subtotal)
print("The sale tax of the five items are:", salestax)
print("The Total amount of the customer purchased five items are:", TA)
#output
Enter item-1 price=850
Enter item-2 price=759
Enter item-3 price=8524
Enter item-4 price=9563
Enter item-5 price=7425
The subtotal of the five items are: 27121.0
The sale tax of the five items are: 1898.47
The Total amount of the customer purchased five items are: 29019.47

#Q:14
A_1h=70
B_6h=70*6
C_10h=70*10
D_15h=70*15
print("The Distance of car travel in 6 hours is:", B_6h)
print("The Distance of car travel in 10 hours is:", C_10h)
print("The Distance of car travel in 15 hours is:", D_15h)
#output
The Distance of car travel in 6 hours is: 420
The Distance of car travel in 10 hours is: 700
The Distance of car travel in 15 hours is: 1050

#Q:15
user=float(input("Enter the amount of purchase:"))
SST=user*5/100
CT=user*2.5/100
TA=user+SST+CT
print("The amount of purchase:",user)
print("The amount state sales tax on purchase:",SST)
print("The amount central sales tax on purchase:",CT)
print("The total amount of purchase:",TA)
#output
Enter the amount of purchase:12500
The amount of purchase: 12500.0
The amount state sales tax on purchase: 625.0
The amount central sales tax on purchase: 312.5
The total amount of purchase: 13437.5

#Q:16
user=float(input("Enter the charge of the food:"))
tip=user*18/100
ST=user*7/100
TA=user+tip+ST
print("The charge of the food is:",user)
print("The tip on the charge of food:",tip)
print("The sales tax on charge of food:",ST)
print("The total charge on the food:",TA)
#output
Enter the charge of the food: 850
The charge of the food is: 850.0
The tip on the charge of food: 153.0
The sales tax on charge of food: 59.5
The total charge on the food: 1062.5












