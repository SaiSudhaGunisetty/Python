Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: D:\python\GSS python Directory\employee details with input 23.12.19.py
Enter employee ID: E1919
Enter employee name: G. Sai Sudha
Enter employee deparment: IT
Enter employee company: Infosys
Enter employee designation: Python Developer
Enter employee salry: 85000
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
EMPLOYEE DETAILS:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
employee ID is: : E1919
employee name is: : G. Sai Sudha
employee deparmentis: : IT
employee company is: : Infosys
employee designation is: : Python Developer
employee salary is: : 85000
>>> 