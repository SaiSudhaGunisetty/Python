print("hospital name is Rain bow")
print("Branches of the hospital are 100")
print("hospital website is www.rainbow.com")

      

      
