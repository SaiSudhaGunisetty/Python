Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=========== RESTART: D:\python\GSS python Directory\input 23.12.19.py ==========
Enter your First name: Noomit
Enter your Last name: Nukella
Enter your Mobile number: 9020251251
Enter your Email ID: nukellanoomit@gmail.com
CUSTOMERINFORMATION
........................................
Dear customer your First name is: Firstname
Dear customer your Last name is: Lastname
Dear customer your Mobile number is: Mobilenumber
Dear customer your Email ID is: EmailID
........................................
>>> 