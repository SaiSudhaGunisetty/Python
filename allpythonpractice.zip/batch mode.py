# batch mode python programming

print("welcome to python world")
print("dear sai sudha")
print("family details:\n Name: Sai Sudha\n Spouse: Balakrishna\n Children: Noomit yagna")
