class Product:
    ShopName="Prestige"
    ShopAddress=" Banglore"
    ShopWebsite="www.prestige.com"    
    def __init__(self,pname, pmodel, pprice):
        self.ProductName=pname
        self.ProductModel=pmodel
        self.ProductPrice=pprice
    def DisplayProductInformation(self):                          
        print("*"*20)
        print("PRODUCT INFORMATION")
        print("*"*20)
        print("Product  Shop Name is", Product.ShopName)
        print("Product Shop Address is", Product.ShopAddress)
        print("Product Shop Website is", Product.ShopWebsite)
        print("Product Name is", self.ProductName)
        print("Product Model is", self.ProductModel)
        print("Product Price is", self.ProductPrice)
        print("*"*20)
    def __del__(self):
        print("object destroyed:", id(self))
a=input("Enter Product name:")
b=input("Enter Product Model:")
c=float(input("Enter Product Price:"))
p1=Product(a,b,c)
p1.DisplayProductInformation()
print("object destroyed:", id(p1))
print("*"*20)
a=input("Enter Product name:")
b=input("Enter Product Model:")
c=float(input("Enter Product Price:"))
p2=Product(a,b,c)
p2.DisplayProductInformation()
print("object destroyed:", id(p2))
print("*"*20)

#output
Enter Product name:Mosquitoe bat
Enter Product Model:Square shaped
Enter Product Price:750
********************
PRODUCT INFORMATION
********************
Product  Shop Name is Prestige
Product Shop Address is  Banglore
Product Shop Website is www.prestige.com
Product Name is Mosquitoe bat
Product Model is Square shaped
Product Price is 750.0
********************
object destroyed: 2282517656384
********************
Enter Product name:Hair dryer
Enter Product Model:phillipes
Enter Product Price:1500
********************
PRODUCT INFORMATION
********************
Product  Shop Name is Prestige
Product Shop Address is  Banglore
Product Shop Website is www.prestige.com
Product Name is Hair dryer
Product Model is phillipes
Product Price is 1500.0
********************
object destroyed: 2282521632624
********************
