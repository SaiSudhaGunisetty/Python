Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> a=5
>>> b=3
>>> a=b
>>> print(a,b)
3 3
>>> print(a)
3
>>> print(b)
3
>>> a=3
>>> b=2.5
>>> print(a and b)
2.5
>>> print(a,b)
3 2.5
>>> a=2.3
>>> b=5
>>> c=a+b
>>> print(c)
7.3
>>> a="satya"
>>> b="tech"
>>> c="satya"+"tech"
>>> print(c)
satyatech
>>> a=2
>>> b=5
>>> c=a,b
>>> print(c)
(2, 5)
>>> (2, 5)a=2.3
SyntaxError: invalid syntax
>>> SyntaxError: invalid syntax
SyntaxError: invalid syntax
>>> 
>>> 
>>> a=2.3
>>> b=9
>>> a=b
>>> print(b)
9
>>> a=5
>>> b=3
>>> c=a+b
>>> print("sum is:", c)
sum is: 8
>>> x=a
>>> y=5
>>> x=y
>>> print(x,y)
5 5
>>> x=2.3
>>> 
>>> x=2.3f
SyntaxError: invalid syntax
>>> x=2.3f
SyntaxError: invalid syntax
>>> 
>>> 
>>> x=2.3
>>> y=3
>>> z=x+y
>>> print(z)
5.3
>>> a=x
>>> b=y
>>> c=a,b
>>> print(c)
(2.3, 3)
>>> x=5
>>> y=2
>>> z=x/y
>>> print(z)
2.5
>>> x=5
>>> x=y
>>> print(y)
2
>>> x=3
>>> y=27
>>> print(x,y)
3 27
>>> x=3
>>> s=9
>>> c=27
>>> print(s,c)
9 27
>>> x=2
>>> s=4
>>> c=8
>>> Sum=s+c
>>> print(Sum)
12
>>> x=5
>>> y=3
>>> z=
SyntaxError: invalid syntax
>>> 