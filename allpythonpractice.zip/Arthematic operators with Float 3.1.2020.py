firstfloat= float(input("Enter first float value="))
secondfloat= float(input("Enter second float value="))
print("Addition is", firstfloat+secondfloat)
print("Substraction is", firstfloat-secondfloat)
print("Multiplication is", firstfloat*secondfloat)
print("Division is", firstfloat/secondfloat)
print("Floor division is", firstfloat//secondfloat)
print("Modulation is",firstfloat %secondfloat)
print("Power is", firstfloat**secondfloat)


output:
     
Enter first float value=250.1
Enter second float value=10.0
Addition is 260.1
Substraction is 240.1
Multiplication is 2501.0
Division is 25.009999999999998
Floor division is 25.0
Modulation is 0.09999999999999432
Power is 9.57495887456301e+23
