
class College:
    CollegeName="CBIT"
    CollegeAddress="Ameerpet"
    CollegeWebsite="www.cbit.com"
def Collegeinformationdisplay():
    print("`"*40)
    print("College Infromation")
    print("`"*40)
    print("College Name is", College.CollegeName)
    print("College Address is", College.CollegeAddress)
    print("College Website is", College.CollegeWebsite)
Collegeinformationdisplay()
