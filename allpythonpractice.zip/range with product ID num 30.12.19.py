productIDNumbers=range(500,1501)
for i in productIDNumbers:
	print(i)




