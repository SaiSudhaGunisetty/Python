class Person:
     def Acceptpersoninformation(self):
          self.PersonName=input("Enter Person Name:")
          self.PersonAge=int(input("Enter Person Age:"))
          self.Personphonenumber=float(input("Enter Person phone number:"))
          self.Personemail=input("Enter Person email:")
     def Displaypersoninformation(self):
          print("-"*25)
          print("INFORMATION:")
          print("-"*25)
          print("Name \t\t:", self.PersonName)
          print("Age \t\t:", self.PersonAge)
          print("Phone number \t:", self.Personphonenumber)
          print("Email ID\t\t:", self.Personemail)
class Employee(Person):
     def AcceptEmployeeinformation(self):
          self.EmployeeID=input("Enter Employee ID:")
          self.EmployeeDept=input("Enter Employee Department:")
          self.EmployeeDesg=input("Enter Employee Designation:")
          self.EmployeeSalary=float(input("Enter Employee Salary:"))
          self.EmployeeCompany=input("Enter Employee Company:")
     def DisplayEmployeeinformation(self):
          print("ID \t\t:", self.EmployeeID)
          print("Department \t:", self.EmployeeDept)
          print("Designation \t:", self.EmployeeDesg)
          print("Salary \t\t:", self.EmployeeSalary)
          print("Company \t:", self.EmployeeCompany)
c=Employee()
c.Acceptpersoninformation()
c.AcceptEmployeeinformation()
c.Displaypersoninformation()
c.DisplayEmployeeinformation()

#output
Enter Person Name:SAI SUDHA.G
Enter Person Age:25
Enter Person phone number:8142601270
Enter Person email:sudha.saisudha249@gmail.com
Enter Employee ID:E1122
Enter Employee Department:IT
Enter Employee Designation:PYTHON DEVELOPER
Enter Employee Salary:75000
Enter Employee Company:INFOSYS
-------------------------
INFORMATION:
-------------------------
Name 		: SAI SUDHA.G
Age 		: 25
Phone number 	: 8142601270.0
Email ID		: sudha.saisudha249@gmail.com
ID 		: E1122
Department 	: IT
Designation 	: PYTHON DEVELOPER
Salary 		: 75000.0
Company 	: INFOSYS




            
