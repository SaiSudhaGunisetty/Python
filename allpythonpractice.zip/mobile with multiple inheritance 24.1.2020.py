class Product:
     def AcceptProductInformation(self):
          self.ProductName=input("Enter product Name:")
          self.ProductCompany=input("Enter product company:")
          self.ProductCompanywebsite=input("Enter product company website:")
     def DisplayProductInformation(self):
          print("Name\t:", self.ProductName)
          print("Company\t:", self.ProductCompany)
          print("Website\t:",self.ProductCompanywebsite)
class ElectronicDevice:
     def AcceptElectronicDeviceInformation(self):
          self.EDID=input("Enter Electronic Device ID:")
          self.EDColour=input("Enter Electronic Device Colour:")
          self.EDModel=input("Enter Electronic Device Model:")
     def DisplayElectronicDeviceInformation(self):
          print("ID\t:", self.EDID)
          print("Colour\t:", self.EDColour)
          print("Model\t:", self.EDModel)
class Mobile(Product, ElectronicDevice):
     def AcceptMobileInformation(self):
          self.MobileRAM=input("Enter mobile RAM:")
          self.MobileROM=input("Enter mobile ROM:")
          self.MobileProcessor=input("Enter mobile Processor:")
     def DisplayMobileInformation(self):
          print("ROM\t:", self.MobileROM)
          print("RAM\t:", self.MobileRAM)
          print("Processor\t:", self. MobileProcessor)
m=Mobile()
m.AcceptProductInformation()
m.AcceptElectronicDeviceInformation()
m.AcceptMobileInformation()
m.DisplayProductInformation()
m.DisplayElectronicDeviceInformation()
m.DisplayMobileInformation()


#output


Enter product Name:Moto G5 S plus
Enter product company:Lenovo
Enter product company website:www.lenovo.com
Enter Electronic Device ID:P1919
Enter Electronic Device Colour:Silver
Enter Electronic Device Model:G5S+
Enter mobile RAM:4GB
Enter mobile ROM:32 
Enter mobile Processor:2.0 
Name	: Moto G5 S plus
Company	: Lenovo
Website	: www.lenovo.com
ID	: P1919
Colour	: Silver
Model	: G5S+
ROM	: 32 
RAM	: 4GB
Processor	: 2.0 











                                     
                                     
         
     
