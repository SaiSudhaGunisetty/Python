Mobileprice=int(input("Dear customer enter Mobile price:"))
if Mobileprice>=70000:
     print("Dear customer you will get 20 % discount")
elif Mobileprice>=60000:
     print("Dear customer you will get 15 % discount")
elif Mobileprice>=50000:
     print("Dear customer you will get 10 % discount")
else:
     print("Dear customer, please collect complementary gift")
     
#output:
Dear customer enter Mobile price:89754
Dear customer you will get 20 % discount
>>> 
========== RESTART: C:/Users/INDIA/Desktop/if..elif..else.. 25.1.2020.py =========
Dear customer enter Mobile price:69854
Dear customer you will get 15 % discount
>>> 
========== RESTART: C:/Users/INDIA/Desktop/if..elif..else.. 25.1.2020.py =========
Dear customer enter Mobile price:51254
Dear customer you will get 10 % discount
>>>
========== RESTART: C:/Users/INDIA/Desktop/if..elif..else.. 25.1.2020.py =========
Dear customer enter Mobile price:125
Dear customer, please collect complementary gift
>>> 
