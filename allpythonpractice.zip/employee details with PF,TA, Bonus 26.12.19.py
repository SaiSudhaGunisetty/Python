employeeID=input("Enter employee ID:")
employeename=input("Enter employee name:")
employeedesignation=input("Enter employee designation:")
employeedepartment=input("Enter employee deparment:")
employeesalary=float(input("Enter employee salary:"))
PF=employeesalary*(15/100)
TA=5000
Bonus=10000
employeesalary=PF+TA+Bonus+employeesalary
print("Total employee salary:", employeesalary)
