Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> a=input()
print(a)
>>> 
>>> a=input()
print(a)
>>> print(typr(a))
Traceback (most recent call last):
  File "<pyshell#3>", line 1, in <module>
    print(typr(a))
NameError: name 'typr' is not defined
>>> print(type(a))
<class 'str'>
>>> a=input("Enterfname:")
Enterfname:b=
>>> 
>>> int(123.654)
123
>>> int(False)
0
>>> int("10")
10
>>> int("10.5")
Traceback (most recent call last):
  File "<pyshell#10>", line 1, in <module>
    int("10.5")
ValueError: invalid literal for int() with base 10: '10.5'
>>> ValueError: invalid literal for int() with base 10: '10.5'
SyntaxError: invalid syntax
>>> 
>>> 
>>> 
>>> int("ten")
Traceback (most recent call last):
  File "<pyshell#15>", line 1, in <module>
    int("ten")
ValueError: invalid literal for int() with base 10: 'ten'
>>> 
>>> float(10)
10.0
>>> 
>>> float(True)
1.0
>>> 
>>> float(False)
0.0
>>> 
>>> float("10")
10.0
>>> float("10.5")
10.5
>>> float("ten")
Traceback (most recent call last):
  File "<pyshell#25>", line 1, in <module>
    float("ten")
ValueError: could not convert string to float: 'ten'
>>> 
>>> bool(0)
False
>>> bool1)
SyntaxError: unmatched ')'
>>> 
>>> 
>>> 
>>> bool(1)
True
>>> bool(10)
True
>>> bool(0.13332)
True
>>> bool(0.0)
False
>>> str(10)
'10'
>>> str(10.5)
'10.5'
>>> str(True)
'True'
>>> str(False)
'False'
>>> z=float("3")
>>> print(10>9)
True
>>> print(10==9)
False
>>> z=float("3")
>>> 
================ RESTART: C:/Users/INDIA/Desktop/page 20. core.py ================
Enterfname:sai
Enterlname:sudha
saisudha
>>> 
================ RESTART: C:/Users/INDIA/Desktop/page 20. core.py ================
Enterfname:7
Enterlname:3
73
>>> 
================ RESTART: C:/Users/INDIA/Desktop/page 20. core.py ================
Enterfname:8
8
<class 'int'>
>>> 
================ RESTART: C:/Users/INDIA/Desktop/page 20. core.py ================
Enterfname:2.5
Traceback (most recent call last):
  File "C:/Users/INDIA/Desktop/page 20. core.py", line 1, in <module>
    a=int(input("Enterfname:"))
ValueError: invalid literal for int() with base 10: '2.5'
>>> 
================ RESTART: C:/Users/INDIA/Desktop/page 20. core.py ================
Enterfname:5
5.0
<class 'float'>
>>> 
================ RESTART: C:/Users/INDIA/Desktop/page 20. core.py ================
Any no:2
2
<class 'int'>
>>> 
================ RESTART: C:/Users/INDIA/Desktop/page 20. core.py ================
Any no:5.4
5.4
<class 'float'>
>>> 
================ RESTART: C:/Users/INDIA/Desktop/page 20. core.py ================
Any no:65
A
>>> 
================ RESTART: C:/Users/INDIA/Desktop/page 20. core.py ================
Any no:97
a
>>> 