#student details progeram

studentname= input("Enter student name:")
studentaddress= input("Enter student address:")
studentmobilenumber= input("Enter mobile number:")
studentcourse= input("Enter student course:")
studentinstitute= input("Enter student Institute:")
print("*"*30)
print("STUDENT DETAILS:")
print("*"*30)
print("Dear student your name is:", studentname)
print("Dear student your address is:", studentaddress)
print("Dear student your mobile number is:", studentmobilenumber)
print("Dear student your course is:", studentcourse)
print("Dear student your Institute is:", studentinstitute)



