AadhaarcardNumber=range(112233,334456)
for i in AadhaarcardNumber:
    print(i)


