Aadhaarcardnumbers=range(11223344,44556678)
Pancardnumbers=range(1234,4568)
ACN=int(input("Enter Aadhaar card number:"))
PAN=int(input("Enter Pan card number:"))
if ACN in Aadhaarcardnumbers and PAN in Pancardnumbers:
     print("Dear customer your details are valid, please do the transaction")
else:
     print("Dear customer please enter the valid details")


#output

Enter Aadhaar card number:11223344
Enter Pan card number:1234
Dear customer your details are valid, please do the transaction
