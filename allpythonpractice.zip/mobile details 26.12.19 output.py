Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
====== RESTART: D:\python\GSS python Directory\mobile details 26.12.19.py ======
Enter mobile model: OPPO F
Enter mobile price 25896
Total mobile price: 27449.76
>>> 