class company:
    name:"TCS"
    address:"Hyderabad"
    branches:"hitech city, ameerpet, himayath nagar"
    website:"www.tcs.com"
def companyinformationdisplay():
    print("."*20)
    print("COMPANY INFORMATION")
    print("."*20)
    print("company name is", company.name)
    print("company address is", company.address)
    print("company branches are", company.branches)
    print("company website is", company.website)
    print("."*20)
companyinformationdisplay()
