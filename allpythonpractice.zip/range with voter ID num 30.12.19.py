voterIDNumbers=range(1111,10000,500)
for i in voterIDNumbers:
    print(i)
