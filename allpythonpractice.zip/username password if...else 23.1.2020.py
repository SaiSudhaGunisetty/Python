UN=input("Enter username:")
PW=int(input("Enter your password:"))
username=UN
password=PW
if username is UN and password is PW:
     print("Welcome")
else:
     print("Please enter valid username and password")



