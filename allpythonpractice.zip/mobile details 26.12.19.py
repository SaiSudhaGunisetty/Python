mobilemodel=input("Enter mobile model")
mobileprice=float(input("Enter mobile price"))
sgst=mobileprice*(2/100)
cgst=mobileprice*(4/100)
gst=sgst+cgst
mobileprice=mobileprice+gst
print("Total mobile price:", mobileprice)
