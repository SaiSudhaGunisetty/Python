Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: D:/python/GSS python Directory/Hospital application with class 1.1.2020.py
Enter Hospital Name is: Dr.Agarwals
Enter Hospital Address is: Hyderabad
Enter Hospital Branches are: Madinaguda
Enter Hospital Specialities: Eyecare
Enter hospital Website is:www.agarwals.com
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Hospital Infromation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Hospital Name is  Dr.Agarwals
Hospital Address is  Hyderabad
Hospital Branches are  Madinaguda
Hospital Specialities are  Eyecare
Hospital Website is www.agarwals.com
>>> 