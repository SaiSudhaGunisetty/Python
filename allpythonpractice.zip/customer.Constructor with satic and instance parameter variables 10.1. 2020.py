class Customer:
    CompanyName="Honda"
    CompanyAddress=" Hyderabad"
    CompanyWebsite="www.honda.com"    
    def __init__(self, cfn, cln, cemailid, cpn):
        self.CustomerFirstname=cfn
        self.CustomerLastname=cln
        self.CustomerEmailID=cemailid
        self.CustomerPhonenumber=cpn
    def DisplayCustomerInformation(self):                          
        print("*"*20)
        print("CUSTOMER INFORMATION")
        print("*"*20)
        print("Customer Company Name is", Customer.CompanyName)
        print("Customer Company Address is", Customer.CompanyAddress)
        print("Customer Company Website is", Customer.CompanyWebsite)
        print("Customer First name is", self.CustomerFirstname)
        print("Customer Last name is", self.CustomerLastname)
        print("Customer Email ID is", self.CustomerEmailID)
        print("Customer Phone number is", self.CustomerPhonenumber)
        print("*"*20)
c1=Customer('Noomit', 'Nukella', 'noomityagna@gmail.com', 8121310413)
c1.DisplayCustomerInformation()
print("*"*20)
c2=Customer('Sai Sudha', 'Gunisetty', 'sudha.saisudha249@gmail.com', 8142601270)
c2.DisplayCustomerInformation()
print("*"*20)

#output

********************
CUSTOMER INFORMATION
********************
Customer Company Name is Honda
Customer Company Address is  Hyderabad
Customer Company Website is www.honda.com
Customer First name is Noomit
Customer Last name is Nukella
Customer Email ID is noomityagna@gmail.com
Customer Phone number is 8121310413
********************
********************
********************
CUSTOMER INFORMATION
********************
Customer Company Name is Honda
Customer Company Address is  Hyderabad
Customer Company Website is www.honda.com
Customer First name is Sai Sudha
Customer Last name is Gunisetty
Customer Email ID is sudha.saisudha249@gmail.com
Customer Phone number is 8142601270
********************
********************



