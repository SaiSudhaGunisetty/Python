a=int(input("Enter  integer:"))
b=float(input("Enter  float:"))
print(a,">", b, ":", a>b)
print(a,"<" , b, ":", a<b)
print(a,">=", b, ":", a>=b)
print(a,"<=" , b, ":", a<=b)
print(a,"==" , b ,":", a==b)
print(a,"!=" , b ,":", a!=b)

#output
Enter  integer:258
Enter  float:32.1
258 > 32.1 : True
258 < 32.1 : False
258 >= 32.1 : True
258 <= 32.1 : False
258 == 32.1 : False
258 != 32.1 : True
