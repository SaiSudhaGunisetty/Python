class Vehicle:
     def AcceptVehicleinformation(self):
          self.VehicleModel=input("Ente Vehicle Model:")
          self.VehicleCompany=input("Enter Vehicle Company:")
          self.VehicleFueltype=input("Enter Vehicle fuel type:")
     def DisplayVehicleinformation(self):
          print("Model\t\t\t\t:", self.VehicleModel)
          print("Company\t\t\t\t:", self.VehicleCompany)
          print("Fueltype\t\t\t\t:", self.VehicleFueltype)
class RegisteredVehicle(Vehicle):
     def AcceptRegisteredVehicleinformation(self):
          self.RVName=input("Enter Registered Vehicle Name:")
          self.RVOName=input("Enter Registered Vehicle Owner's Name:")
          self.RVRN=input("Enter Registered Vehicle Registration Number:")
          self.RVRDate=input("Enter Registred Vehicle Registration Date:")
          self.RVPlace=input("Enter Registered Vehicle Registration place:")
     def DisplayRegisteredVehicleinformation(self):
          print("Name \t\t\t\t:", self.RVName)
          print("Owner's Name\t\t\t:", self.RVOName)
          print("Registration No\t\t\t:", self.RVRN)
          print("Date of Registration\t\t:", self.RVRDate)
          print("Place of Registration\t\t:", self.RVPlace)
class Aeroplane(RegisteredVehicle):
     def AcceptAeroplaneinformation(self):
          self.AeroplaneHeight=float(input("Enter Aeroplane Height:"))
          self.AeroplaneWeight=float(input("Enter Aeroplane Weight:"))
          self.AeroplaneSeatingCapacity=int(input("Enter Aeroplane seating capacity:"))
          self.AeroplanePrice=float(input("Enter Aeroplane Price:"))
     def DisplayAeroplaneinformation(self):
          print("Height\t\t\t\t:", self.AeroplaneHeight)
          print("Weight\t\t\t\t:", self.AeroplaneWeight)
          print("Seating capacity\t\t\t:", self.AeroplaneSeatingCapacity)
          print("Price\t\t\t\t:", self.AeroplanePrice)
class CargoAeroplane(Aeroplane):
     def AcceptCargoAeroplaneinformation(self):
          self.CargoAeroplaneHeight=float(input("Enter CargoAeroplane Height:"))
          self.CargoAeroplaneGoodsCarryingWeight=float(input("Enter CargoAeroplane Goods Carrying Weight:"))
          self.CargoAeroplaneGoodsCarryingType=input("Enter CargoAeroplane Goods Carrying Type:")
     def DisplayCargoAeroplaneinformation(self):
          print("Height\t\t\t\t:", self.CargoAeroplaneHeight)
          print("Goods Carrying Weight \t\t:", self.CargoAeroplaneGoodsCarryingWeight)
          print("Goods Carrying Type \t\t:", self.CargoAeroplaneGoodsCarryingType)
class PassangerAeroplane(Aeroplane):
     def AcceptPassangerAeroplaneinformation(self):
          self.PassangerAeroplaneHeight=float(input("Enter PassangerAeroplane Height:"))
          self.PassangerAeroplaneWeight=float(input("Enter PassangerAeroplane Weight:"))
          self.PassangerAeroplaneSeatingCapacity=int(input("Enter Passanger Aeroplane seating capacity:"))
     def DisplayPassangerAeroplaneinformation(self):
          print("Height\t\t\t\t:", self.PassangerAeroplaneHeight)
          print("Weight\t\t\t\t:", self.PassangerAeroplaneWeight)
          print("Seating capacity\t\t\t:", self.PassangerAeroplaneSeatingCapacity)
c=CargoAeroplane()
c.AcceptVehicleinformation()
c.AcceptRegisteredVehicleinformation()
c.AcceptAeroplaneinformation()
c.AcceptCargoAeroplaneinformation()
print("-"*50)
print("CargoAeroplane:")
print("-"*50)
c.DisplayVehicleinformation()
c.DisplayRegisteredVehicleinformation()
c.DisplayAeroplaneinformation()
c.DisplayCargoAeroplaneinformation()
print("-"*50)
p=PassangerAeroplane()
p.AcceptVehicleinformation()
p.AcceptRegisteredVehicleinformation()
p.AcceptAeroplaneinformation()
p.AcceptPassangerAeroplaneinformation()
print("-"*50)
print("PassangerAeroplane:")
print("-"*50)
p.DisplayVehicleinformation()
p.DisplayRegisteredVehicleinformation()
p.DisplayAeroplaneinformation()
p.DisplayPassangerAeroplaneinformation()
print("-"*50)


#output:
======= RESTART: C:/Users/INDIA/Desktop/gss/hybrid inheritance 26.1.2020.py ======
Ente Vehicle Model:Flying model
Enter Vehicle Company:Fairey
Enter Vehicle fuel type:Aviation gasoline
Enter Registered Vehicle Name:Aircraft
Enter Registered Vehicle Owner's Name:Federal Aviation Administration
Enter Registered Vehicle Registration Number:A16-97
Enter Registred Vehicle Registration Date:13/9/1988
Enter Registered Vehicle Registration place:Delhi
Enter Aeroplane Height:12
Enter Aeroplane Weight:1500
Enter Aeroplane seating capacity:1000
Enter Aeroplane Price:1567423800
Enter CargoAeroplane Height:18
Enter CargoAeroplane Goods Carrying Weight:1233456
Enter CargoAeroplane Goods Carrying Type:Grassorries
----------------------------------------------------------------------------
CargoAeroplane:
----------------------------------------------------------------------------
Model				: Flying model
Company				: Fairey
Fueltype				: Aviation gasoline
Name 				: Aircraft
Owner's Name			: Federal Aviation Administration
Registration No			: A16-97
Date of Registration		: 13/9/1988
Place of Registration		: Delhi
Height				: 12.0
Weight				: 1500.0
Seating capacity			: 1000
Price				: 1567423800.0
Height				: 18.0
Goods Carrying Weight 		: 1233456.0
Goods Carrying Type 		: Grassorries
----------------------------------------------------------------------------
Ente Vehicle Model:Non Flying model
Enter Vehicle Company:Aircraft
Enter Vehicle fuel type:Nicobar
Enter Registered Vehicle Name:Indian Airlines
Enter Registered Vehicle Owner's Name:Air India
Enter Registered Vehicle Registration Number:12
Enter Registred Vehicle Registration Date:23/07/2018
Enter Registered Vehicle Registration place:Hyderabad
Enter Aeroplane Height:75
Enter Aeroplane Weight:159753
Enter Aeroplane seating capacity:2000
Enter Aeroplane Price:1597532846
Enter PassangerAeroplane Height:65
Enter PassangerAeroplane Weight:85234
Enter Passanger Aeroplane seating capacity:2500
----------------------------------------------------------------------------
PassangerAeroplane:
----------------------------------------------------------------------------
Model				: Non Flying model
Company				: Aircraft
Fueltype				: Nicobar
Name 				: Indian Airlines
Owner's Name			: Air India
Registration No			: 12
Date of Registration		: 23/07/2018
Place of Registration		: Hyderabad
Height				: 75.0
Weight				: 159753.0
Seating capacity			: 2000
Price				: 1597532846.0
Height				: 65.0
Weight				: 85234.0
Seating capacity			: 2500
----------------------------------------------------------------------------




         
                
     
