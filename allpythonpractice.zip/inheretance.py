class Person:
     def Acceptpersoninformation(self):
               self.PersonName=input("Enter Person Name:")
               self.PersonAge=int(input("Enter Person Age:"))
               self.PersonHeight=float(input("Enter Person Height:"))
               self.PersonWeight=float(input("Enter Person Weight:"))
     def Displaypersoninformation(self):
          print("-"*25)
          print("STUDENT INFORMATION")
          print("-"*25)
          print("Name \t:", self.PersonName)
          print("Age \t:", self.PersonAge)
          print("Height \t:", self.PersonHeight)
          print("Weight \t:", self.PersonWeight)
class Student(Person):
     def Acceptstudentinformation(self):
          self.StudentID=input("Enter Student ID:")
          self.StudentCourse=input("Enter Student Course:")
          self.StudentInstitution=input("Enter Student Institution:")
     def DisplayStudentinformation(self):
          print("ID \t:", self.StudentID)
          print("Course \t:", self.StudentCourse)
          print("Institute \t:", self.StudentInstitution)
S=Student()
S.Acceptpersoninformation()
S.Acceptstudentinformation()
S.Displaypersoninformation()
S.DisplayStudentinformation()

#output
Enter Person Name:Noomit Yagna
Enter Person Age:2
Enter Person Height:2.3
Enter Person Weight:12
Enter Student ID:S1122
Enter Student Course:Play School
Enter Student Institution:Dreamy World
-------------------------
STUDENT INFORMATION
-------------------------
Name 	: Noomit Yagna
Age 	: 2
Height 	: 2.3
Weight 	: 12.0
ID 	: S1122
Course 	: Play School
Institute 	: Dreamy World
            
