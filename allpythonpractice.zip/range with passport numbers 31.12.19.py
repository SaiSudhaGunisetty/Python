VehicleRegistrationNumber=range(2019,2031)
VRN=input("Dear customer enter your Vehicle Registration Number:")
if VRN in VehicleRegistrationNumber:
    print("Dear customer your Vehicle Registration Number is valid")

else:
        print("Dear customer your Vehicle Registration Number is invalid")
