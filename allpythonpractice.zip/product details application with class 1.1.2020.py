
class Product:
    Name="Mobile phone"
    Model="G5 S plus"
    company="Moto"
    website="www.moto.com"
def Productinformationdisplay():
    print("~"*40)
    print("Product Infromation")
    print("~"*40)
    print("Product Name is", Product.Name)
    print("Product Model is", Product.Model)
    print("Product company is", Product.company)
    print("Product website is",Product.website)
Productinformationdisplay()
