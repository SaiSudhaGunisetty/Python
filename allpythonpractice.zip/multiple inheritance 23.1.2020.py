class Person:
     def Acceptpersoninformation(self):
          self.PersonName=input("Enter Person Name:")
          self.PersonAge=int(input("Enter Person Age:"))
          self.Personphonenumber=float(input("Enter Person phone number:"))
          self.Personemail=input("Enter Person email:")
     def Displaypersoninformation(self):
          print("-"*25)
          print("INFORMATION:")
          print("-"*25)
          print("Name \t\t:", self.PersonName)
          print("Age \t\t:", self.PersonAge)
          print("Phone number \t:", self.Personphonenumber)
          print("Email ID\t\t:", self.Personemail)
class Employee (Person):
     def AcceptEmployeeinformation(self):
          self.EmployeeID=input("Enter Employee ID:")
          self.EmployeeDept=input("Enter Employee Department:")
          self.EmployeeDesg=input("Enter Employee Designation:")
          self.EmployeeSalary=float(input("Enter Employee Salary:"))
     def DisplayEmployeeinformation(self):
          print("ID \t\t:", self.EmployeeID)
          print("Department \t:", self.EmployeeDept)
          print("Designation \t:", self.EmployeeDesg)
          print("Salary \t\t:", self.EmployeeSalary)
class Teacher(Person, Employee):
     def AcceptTeacherinformation(self):
          self.TeacherSchool=input("Enter Teacher's School:")
          self.TeacherSubject=input("Enter Teacher's Subject:")
          self.TeacherClass=input("Enter Teacher's Class:")
     def DisplayTeacherinformation(self):
          print("School \t:", self.TeacherSchool)
          print("Subject \t:", self.TeacherSubject)
          print("Class \t:", self.TeacherClass)
          
t=Teacher()
t.AcceptPersoninformation()
t.DisplayPersoninformation()
t.AcceptEmployeeinformation()
t.DisplayEmployeeinformation()
t.AcceptTeacherinformation()
t.DisplayTeacherinformation()

