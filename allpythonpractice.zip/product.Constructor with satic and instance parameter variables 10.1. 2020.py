class Product:
    ShopName="Prestige"
    ShopAddress=" Banglore"
    ShopWebsite="www.prestige.com"    
    def __init__(self,pname, pmodel, pprice):
        self.ProductName=pname
        self.ProductModel=pmodel
        self.ProductPrice=pprice
    def DisplayProductInformation(self):                          
        print("*"*20)
        print("PRODUCT INFORMATION")
        print("*"*20)
        print("Product  Shop Name is", Product.ShopName)
        print("Product Shop Address is", Product.ShopAddress)
        print("Product Shop Website is", Product.ShopWebsite)
        print("Product Name is", self.ProductName)
        print("Product Model is", self.ProductModel)
        print("Product Price is", self.ProductPrice)
        print("*"*20)
a=input("Enter Product name:")
b=input("Enter Product Model:")
c=float(input("Enter Product Price:"))
p1=Product(a,b,c)
p1.DisplayProductInformation()
print("*"*20)
a=input("Enter Product name:")
b=input("Enter Product Model:")
c=float(input("Enter Product Price:"))
p2=Product(a,b,c)
p2.DisplayProductInformation()
print("*"*20)

#output
********************
PRODUCT INFORMATION
********************
Product  Shop Name is Prestige
Product Shop Address is  Banglore
Product Shop Website is www.prestige.com
Product Name is Prestige Pressure Coocker
Product Model is 1.5L Induction multipurpose Pressure Coocker
Product Price is 4575.3
********************
********************
Enter Product name: Mixer Grinder
Enter Product Model:Iris 750 Watt white blue model
Enter Product Price:7500
********************
PRODUCT INFORMATION
********************
Product  Shop Name is Prestige
Product Shop Address is  Banglore
Product Shop Website is www.prestige.com
Product Name is  Mixer Grinder
Product Model is Iris 750 Watt white blue model
Product Price is 7500.0
********************
********************

