PanCardNumber=range(1919,4000)
PCN=input("Dear customer enter your Pan card Number:")
if PCN in PanCardNumber:
    print("Dear customer your Pan card number is valid")

else:
        print("Dear customer your Pan card number is valid")
