a=int(input("Enter first integer= "))
b=int(input("Enter second integer= "))
print("Addition:",a+b)
print("Subtraction:",a-b)
print("Multiplication:",a*b)
print("Division:",a/b)
print("Modulus",a//b)
print("exponential",a**b)


       
