class Customer:
    CompanyName="Amazon"
    CompanyAddress=" Hyderabad"
    CompanyWebsite="www.amazon.com"    
    def AcceptCustomerData(self, cfn, cln, cemailid, cpn):
        self.CustomerFirstname=cfn
        self.CustomerLastname=cln
        self.CustomerEmailID=cemailid
        self.CustomerPhonenumber=cpn
    def DisplayCustomerInformation(self):                          
        print("*"*20)
        print("CUSTOMER INFORMATION")
        print("*"*20)
        print("Customer Company Name is", Customer.CompanyName)
        print("Customer Company Address is", Customer.CompanyAddress)
        print("Customer Company Website is", Customer.CompanyWebsite)
        print("Customer First name is", self.CustomerFirstname)
        print("Customer Last name is", self.CustomerLastname)
        print("Customer Email ID is", self.CustomerEmailID)
        print("Customer Phone number is", self.CustomerPhonenumber)
        print("*"*20)
c1=Customer()
c1.AcceptCustomerData('Balu', 'Nukella', 'balakrishnanukella@gmail.com', 9030251251)
c1.DisplayCustomerInformation()
print("*"*20)
c2=Customer()
c2.AcceptCustomerData('Sudha', 'Gunisetty', 'sudha.saisudha249@gmail.com', 8142601270)
c2.DisplayCustomerInformation()
print("*"*20)

#output

********************
CUSTOMER INFORMATION
********************
Customer Company Name is Amazon
Customer Company Address is  Hyderabad
Customer Company Website is www.amazon.com
Customer First name is Balu
Customer Last name is Nukella
Customer Email ID is balakrishnanukella@gmail.com
Customer Phone number is 9030251251
********************
********************
********************
CUSTOMER INFORMATION
********************
Customer Company Name is Amazon
Customer Company Address is  Hyderabad
Customer Company Website is www.amazon.com
Customer First name is Sudha
Customer Last name is Gunisetty
Customer Email ID is sudha.saisudha249@gmail.com
Customer Phone number is 8142601270
********************
********************


