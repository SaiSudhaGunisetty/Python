class Employee:
    CompanyName="Tech mahendra"
    CompanyAddress="Ameerpet, Hyderabad"
    CompanyWebsite="www.techmahendra.com"    
    def AcceptEmployeeData(self,eid,ename,eaddress,edept,edesig,esalary):
        self.EmployeeID=eid
        self.EmployeeName=ename
        self.EmployeeAddress=eaddress
        self.EmployeeDepartment =edept
        self.EmployeeDesignation=edesig
        self.EmployeeSalary=esalary
    def DisplayEmployeeInformation(self):                          
        print("*"*20)
        print("EMPLOYEE INFORMATION")
        print("*"*20)
        print("Employee Company Name is", Employee.CompanyName)
        print("Employee Company Address is", Employee.CompanyAddress)
        print("Employee Company Website is", Employee.CompanyWebsite)
        print("Employee ID is", self.EmployeeID)
        print("Employee Name is", self.EmployeeName)
        print("Employee Address is", self.EmployeeAddress)
        print("Employee Deparment is", self.EmployeeDepartment)
        print("Employee Designation is", self.EmployeeDesignation)
        print("Employee Salary is", self.EmployeeSalary)
        print("*"*20)
e1=Employee()
a=input("Enter Employee ID:")
b=input("Enter Employee Name:")
c=input("Enter Employee Address:")
d =input("Enter Employee Department:")
e=input("Enter Employee Designation:")
f=float(input("Enter Employee Salary:"))
e1.AcceptEmployeeData(a,b,c,d,e,f)
e1.DisplayEmployeeInformation()
print("*"*20)
e2=Employee()
a=input("Enter Employee ID:")
b=input("Enter Employee Name:")
c=input("Enter Employee Address:")
d =input("Enter Employee Department:")
e=input("Enter Employee Designation:")
f=float(input("Enter Employee Salary:"))
e2.AcceptEmployeeData(a,b,c,d,e,f)
e2.DisplayEmployeeInformation()
print("*"*20)

#output

Enter Employee ID:E1234
Enter Employee Name:Balakrishna
Enter Employee Address:Lingampally
Enter Employee Department:IT
Enter Employee Designation:Senior python developer
Enter Employee Salary:250000
********************
EMPLOYEE INFORMATION
********************
Employee Company Name is Tech mahendra
Employee Company Address is Ameerpet, Hyderabad
Employee Company Website is www.techmahendra.com
Employee ID is E1234
Employee Name is Balakrishna
Employee Address is Lingampally
Employee Deparment is IT
Employee Designation is Senior python developer
Employee Salary is 250000.0
********************
********************
Enter Employee ID:E2356
Enter Employee Name:SaiSudha
Enter Employee Address:SR nagar
Enter Employee Department:IT
Enter Employee Designation:Tester
Enter Employee Salary:80000
********************
EMPLOYEE INFORMATION
********************
Employee Company Name is Tech mahendra
Employee Company Address is Ameerpet, Hyderabad
Employee Company Website is www.techmahendra.com
Employee ID is E2356
Employee Name is SaiSudha
Employee Address is SR nagar
Employee Deparment is IT
Employee Designation is Tester
Employee Salary is 80000.0
********************
********************
