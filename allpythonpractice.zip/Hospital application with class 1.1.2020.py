
class Hospital:
    HospitalName=input("Enter Hospital Name is:")
    HospitalAddress=input("Enter Hospital Address is:")
    HospitalBranches=input("Enter Hospital Branches are:")
    HospitalSpecialities=input("Enter Hospital Specialities:")
    HospitalWebsite=input("Enter hospital Website is:")
def Hospitalinformationdisplay():
    print("~"*40)
    print("Hospital Infromation")
    print("~"*40)
    print("Hospital Name is", Hospital.HospitalName)
    print("Hospital Address is", Hospital.HospitalAddress)
    print("Hospital Branches are", Hospital.HospitalBranches)
    print("Hospital Specialities are",Hospital.HospitalSpecialities)
    print("Hospital Website is", Hospital.HospitalWebsite)
Hospitalinformationdisplay()
