customerIDnumbers=range(2250,999,-100)
for i in customerIDnumbers:
    print(i)
