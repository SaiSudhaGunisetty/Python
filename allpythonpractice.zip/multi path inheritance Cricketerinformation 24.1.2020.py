class person:
     def Acceptpersoninformation(self):
          self.PersonName=input("Enter person name:")
          self.PersonAge=int(input("Enter person age:"))
          self.PersonGender=input("Enter person gender:")
          self.PersonAddress=input("Enter person address:")
     def Displaypersoninformation(self):
          print("Name\t:", self.PersonName)
          print("Age\t:", self.PersonAge)
          print("Gender\t:", self.PersonGender)
          print("Address\t:", self.PersonAddress)
class Bowler(person):
     def AcceptBowlerinformation(self):
          self.BowlerSpeed=int(input("Enter Bowler speed:"))
          self.BowlerStyle=input("Enter Bowler Style:")
          self.BowlerRanking=int(input("Enter Bowler Ranking:"))
     def DisplayBowlerinformation(self):
          print("Bowler Speed:", self.BowlerSpeed)
          print("Bowler Style:", self.BowlerStyle)
          print("Bowler Ranking:", self.BowlerRanking)
class Batsman(person):
     def AcceptBatsmaninformation(self):
          self.BatsmanSpeed=int(input("Enter Batsman Speed:"))
          self.BatsmanStyle=input("Enter Batsman Style:")          
          self.BatsmanRanking=int(input("Enter Batsman Ranking:"))
     def DisplayBatsmaninformation(self):
          print("Batsman Speed:", self.BatsmanSpeed)
          print("Batsman Style:", self.BatsmanStyle)
          print("Batsman Ranking:", self.BatsmanRanking)
class Cricketer(Bowler, Batsman):
     def AcceptCricketerinformation(self):
          self.CricketerCountryName=input("Enter Cricketer Country Name:")
          self.CricketerNoofMatchesPlayed=int(input("Enter Cricketer Number of Matches Played:"))
          self.CricketerNumberofWicketsTaken=int(input("Enter Cricketer Number of Wickets Taken:"))
          self.CricketerRanking=int(input("Enter Cricketer Ranking:"))
     def DisplayCricketerinformation(self):
          print("Cricketer Country Name:", self.CricketerCountryName)
          print("Cricketer No.of Matches Played:", self.CricketerNoofMatchesPlayed)
          print("Cricketer No.of Wickets Taken:", self.CricketerNumberofWicketsTaken)
          print("Cricketer Ranking:", self.CricketerRanking)
c=Cricketer()
c.Acceptpersoninformation()
c.AcceptBowlerinformation()
c.AcceptBatsmaninformation()
c.AcceptCricketerinformation()
c.Displaypersoninformation()
c.DisplayBowlerinformation()
c.DisplayBatsmaninformation()
c.DisplayCricketerinformation()

#output
Enter person name:Balakrishna.N
Enter person age:32
Enter person gender:M
Enter person address:Hyderabad
Enter Bowler speed:6
Enter Bowler Style:Right
Enter Bowler Ranking:2
Enter Batsman Speed:4
Enter Batsman Style:Left
Enter Batsman Ranking:3
Enter Cricketer Country Name:India
Enter Cricketer Number of Matches Played:29
Enter Cricketer Number of Wickets Taken:10
Enter Cricketer Ranking:3
Name	: Balakrishna.N
Age	: 32
Gender	: M
Address	: Hyderabad
Bowler Speed: 6
Bowler Style: Right
Bowler Ranking: 2
Batsman Speed: 4
Batsman Style: Left
Batsman Ranking: 3
Cricketer Country Name: India
Cricketer No.of Matches Played: 29
Cricketer No.of Wickets Taken: 10
Cricketer Ranking: 3

                              
