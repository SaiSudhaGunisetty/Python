class Student:
     CollegeName="SKR & SKR Women college"
     Collegeaddress="Kadapa"
     Collegewebsite="www.skrwomenclg.edu"
     def AcceptStudentInformation(self):
          self.StudentID=input("Enter Student ID:")
          self.StudentName=input("Enter Student Name:")
          self.StudentCourse=input("Enter Stdent Course:")
     def DisplayStudentInformation(self):
          print("~"*20)
          print("STUDENT INFORMATION")
          print("~"*20)
          print("Student college name is:", Student.CollegeName)
          print("Student collge address is:", Student.Collegeaddress)
          print("Student college website is:", Student.Collegewebsite)
          print("Student ID is:", self.StudentID)
          print("Student name is:", self.StudentName)
          print("Student course is:", self.StudentCourse)
          print("~"*20)
s1=Student()
s1.AcceptStudentInformation()
s1.DisplayStudentInformation()
print("~"*20)
s2=Student()
s2.AcceptStudentInformation()
s2.DisplayStudentInformation()

#output
Enter Student ID:S1122
Enter Student Name:G.SaiSudha
Enter Stdent Course:Biotechnology
~~~~~~~~~~~~~~~~~~~~
STUDENT INFORMATION
~~~~~~~~~~~~~~~~~~~~
Student college name is: SKR & SKR Women college
Student collge address is: Kadapa
Student college website is: www.skrwomenclg.edu
Student ID is: S1122
Student name is: G.SaiSudha
Student course is: Biotechnology
~~~~~~~~~~~~~~~~~~~~
~~~~~~~~~~~~~~~~~~~~
Enter Student ID:S2233
Enter Student Name:B.Manjusha
Enter Stdent Course:Bioinformatics
~~~~~~~~~~~~~~~~~~~~
STUDENT INFORMATION
~~~~~~~~~~~~~~~~~~~~
Student college name is: SKR & SKR Women college
Student collge address is: Kadapa
Student college website is: www.skrwomenclg.edu
Student ID is: S2233
Student name is: B.Manjusha
Student course is: Bioinformatics
~~~~~~~~~~~~~~~~~~~~
