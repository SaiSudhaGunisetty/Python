a=int(input("Enter first integer value="))
b=int(input("Enter second integer value="))
a+=b
print("After addition 'a' is:", a)
a-=b
print("After subtraction 'a' is:", a)
a*=b
print("After multiplication 'a' is:", a)
a/=b
print("After division 'a' is:", a)
a//=b
print("After floor division 'a' is:", a)
a%=b
print("After modulation 'a' is:", a)
a**=b
print("After power 'a' is:", a)

output:
Enter first integer value=12
Enter second integer value=3
After addition 'a' is: 15
After subtraction 'a' is: 12
After multiplication 'a' is: 36
After division 'a' is: 12.0
After floor division 'a' is: 4.0
After modulation 'a' is: 1.0
After power 'a' is: 1.0
