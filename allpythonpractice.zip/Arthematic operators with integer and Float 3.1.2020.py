a= float(input("Enter  float value="))
b= int(input("Enter  integer value="))
print("Addition is", a+b)
print("Substraction is", a-b)
print("Multiplication is", a*b)
print("Division is", a/b)
print("Floor division is", a//b)
print("Modulation is", a%b)
print("Power is", a**b)

output:
Enter  float value=452.1
Enter  integer value=2
Addition is 454.1
Substraction is 450.1
Multiplication is 904.2
Division is 226.05
Floor division is 226.0
Modulation is 0.10000000000002274
Power is 204394.41000000003
