Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> a=1000
>>> b=200
>>> c=a if a>b else b
>>> c
1000
>>> p=500
>>> q=750
>>> r=p if q>q else q
>>> r
750
>>> 
>>> p&=q
>>> p
228
>>> p=10
>>> q=20
>>> p&=q
>>> p
0
>>> p|=q
>>> p
20
>>> p^=q
>>> p
0
>>> p>>=q
>>> p
0
>>> p<<=q
>>> p
0
>>> p~=q
SyntaxError: invalid syntax
>>> p=~q
>>> p
-21
>>> p&q
0
>>> p|q
-1
>>> p^q
-1
>>> p>>q
-1
>>> p<<q
-22020096
>>> p~q
SyntaxError: invalid syntax
>>> ~p
20
>>> ~q
-21
>>> ~=p
SyntaxError: invalid syntax
>>> q=~
SyntaxError: invalid syntax
>>> =~q
SyntaxError: invalid syntax
>>> p=~q
>>> 
>>> p|qp&=q