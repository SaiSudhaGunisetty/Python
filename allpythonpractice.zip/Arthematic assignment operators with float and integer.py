a=float(input("Enter first float value="))
b=int(input("Enter second integer value="))
a+=b
print("After addition 'a' is:", a)
a-=b
print("After subtraction 'a' is:", a)
a*=b
print("After multiplication 'a' is:", a)
a/=b
print("After division 'a' is:", a)
a//=b
print("After floor division 'a' is:", a)
a%=b
print("After modulation 'a' is:", a)
a**=b
print("After power 'a' is:", a)

output:
Enter first float value=482.6
Enter second integer value=24
After addition 'a' is: 506.6
After subtraction 'a' is: 482.6
After multiplication 'a' is: 11582.400000000001
After division 'a' is: 482.6000000000001
After floor division 'a' is: 20.0
After modulation 'a' is: 20.0
After power 'a' is: 1.6777216e+31

