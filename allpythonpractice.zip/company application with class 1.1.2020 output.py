Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=== RESTART: C:/Users/INDIA/Desktop/compny application with class 1.1.2020.py ==
Enter Company Name is: LG electronics
Enter Company Address is: Banglore
Enter CompanyBranches are: Hyderabad, Chennai, Banglore
Enter Company Employee ID numbers: 111-999
Enter Company Website is:www.lgelectronics.com
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Company Infromation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Company Name is  LG electronics
Company Address is  Banglore
Company Branches are  Hyderabad, Chennai, Banglore
Company Specialities are  111-999
Company Website is www.lgelectronics.com
>>> 