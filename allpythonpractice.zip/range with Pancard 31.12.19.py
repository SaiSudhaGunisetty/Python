PassportNumber=range(11021,20001)
PN=input("Dear customer enter your Passport Number:")
if PN in PassportNumber:
    print("Dear customer your Passport number is valid")

else:
        print("Dear customer your Passport number is valid")
