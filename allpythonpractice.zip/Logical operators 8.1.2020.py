Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 100>50 and 1!=2 and 500>100 and 2==2 and -1>0
False
>>> 100>50 and 1!=2 and 500>100 and 2==2 and -1<0
True
>>> 10==20 or -3>0 or 1000>3000 or 10000!=1
True
>>> 100>200 or 300==400 or 10!=20
True
>>> 100>200 and 1!=2 or 1==1
True
>>> 1000<50 or 1==1 and 400!=100 or 5==6
True
>>> not(1000<50 or 1==1 and 400!=100 or 5==6)
False
>>> not 1000<50 or 1==1 and 400!=100 or 5==6
True
>>> 