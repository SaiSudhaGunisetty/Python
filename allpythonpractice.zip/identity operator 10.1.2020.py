Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> a=100
>>> b=25
>>> id(a)
140716058202880
>>> id(b)
140716058200480
>>> a=b=100
>>> 
>>> a=100
>>> b=100
>>> id(a)
140716058202880
>>> id(b)
140716058202880
>>> a=b=100
>>> a=b
>>> a is b
True
>>> a is not b
False
>>> 
>>> i=1000
>>> j=2000
>>> i is j
False
>>> i is not j
True
>>> 
>>> p=200
>>> q=800
>>> r=200
>>> s=200
>>> t=200
>>> p is r is s is t
True
>>> q is p
False
>>> 
>>> a=100
>>> b=25
>>> a>b and a==b and a<b and a!=b
False
>>> a>b or a==b or a<b or a!=b
True
>>> a>b not a!=b and a>=b
SyntaxError: invalid syntax
>>> not(a>b)
False
>>> not a<b and a!=b
True
>>> 
>>> 
>>> c=a if a>b else b
>>> c=a if a>b else b:
	
SyntaxError: invalid syntax
>>> 
>>> a=12
>>> b=2
>>>  c=a if a>b else b
 
SyntaxError: unexpected indent
>>> c=a if a>b else b
>>> i=10
>>> j=2
>>> l=i if i>j else j
>>> c=i
>>> 
>>> 