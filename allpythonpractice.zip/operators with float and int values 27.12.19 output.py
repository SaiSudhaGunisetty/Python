Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: D:\python\GSS python Directory\operators with float and int values 27.12.19.py
enter first float value=20
enter second float value=14
enter integer value=2
addition is: 36.0
subtraction is: 4.0
multiplications is: 560.0
division 0.7142857142857143
trancating division 0.0
exponential: 1.0043362776618689e+255
>>> 