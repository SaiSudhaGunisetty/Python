a= 100
b= 2
print("Addition is", a+b)
print("Substraction is", a-b)
print("Multiplication is", a*b)
print("Division is", a/b)
print("Floor division is", a//b)
print("Modulation is", a%b)
print("Power is", a**b)



output:

Addition is 102
Substraction is 98
Multiplication is 200
Division is 50.0
Floor division is 50
Modulation is 0
Power is 10000
