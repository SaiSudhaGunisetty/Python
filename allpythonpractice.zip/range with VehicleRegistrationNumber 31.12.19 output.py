Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: D:/python/GSS python Directory/range with passport numbers 31.12.19.py
Dear customer enter your Vehicle Registration Number: 2036
Dear customer your Vehicle Registration Number is invalid
>>> 