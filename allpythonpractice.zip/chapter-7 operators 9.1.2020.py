Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
>>> 2+3-5*6+7-9*3/2
-31.5
>>> 3*4-5/6+7-8*9+2-3*7
-72.83333333333334
>>> 6-7*8+9/5-8%3-7/2-3
-56.7
>>> 3*5-7+7-7/7+7%7
14.0
>>> 3>=5-6+7-8
True
>>> 2>=4 and 3==4
False
>>> 2>=4 or3==4
SyntaxError: invalid syntax
>>> 2>=4 or 3==4
False
>>> i=5
>>> 
>>> i=5;
>>> j=6;
>>> i=i+j;
>>> j=j+i
>>> print(i);
11
>>> print(j);
17
>>> i=2*3+5*6//7-3//2+7*6//3;
>>> j=i-3*4-5*6+7-3*4+7;
>>> i=i+j;
>>> j=j-i*3/2;
>>> i=i*7/-2+5;
>>> j=j-3*4%7;
>>> print(i);
-16.0
>>> print(j);
-31.0
>>> 
>>> i=3*4-6+7//2+4;
>>> j=3*5-6//7+8%9-3*5+7;
>>> i=i+j;
>>> j=j-i;
>>> 
KeyboardInterrupt
>>> print(i);
28
>>> print(j);
-13
>>> 
>>> a="sathya";
>>> b="Tech";
>>> c=a+b;
>>> print(c);
sathyaTech
>>> s="output is"+2+3;
Traceback (most recent call last):
  File "<pyshell#37>", line 1, in <module>
    s="output is"+2+3;
TypeError: can only concatenate str (not "int") to str
>>> 
>>> s="output is" +2+3;
Traceback (most recent call last):
  File "<pyshell#39>", line 1, in <module>
    s="output is" +2+3;
TypeError: can only concatenate str (not "int") to str
>>> 
>>> s=2+3+5*6+7-3*5//6;
>>> print(s);
40
>>> b=5+2-3*5+7/2-3/4>6-5+4*3/9+9-2/3;
>>> print(b);
False
>>> i=7;
>>> j=3;
>>> b=i>=j;
>>> print(b);
True
>>> print(2+3-5*6+7-8)
-26
>>> print(5**6)
15625
>>> print(5*6)
30
>>> print(2+4)
6
>>> print(2+3.5)
5.5
>>> print((2>3))
False
>>> print(12//5+12%5)
4
>>> 3>4 and 3<5
False
>>> 5+3*7-9>4+5*6 and 4<5
False
>>> 4**4
256
>>> 6*2-3/4+4-3//2
14.25
>>> 