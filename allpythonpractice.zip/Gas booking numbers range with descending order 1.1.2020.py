GasBookingnumbers=range(5000,999,-500)
for i in GasBookingnumbers:
    print(i)
