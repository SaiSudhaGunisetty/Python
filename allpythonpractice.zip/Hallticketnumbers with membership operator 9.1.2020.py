Hallticketnumbers=range(10023,11026)
Ht=int(input("Enter your Hallticket number:"))
if Ht in Hallticketnumbers:
     print("Dear Student you have got the Qualified marks:\t'Congratulations'")
else:
     print("Dear Student:\t'Better luck next time'")


#output
Enter your Hallticket number:10023
Dear Student you have got the Qualified marks:	'Congratulations'

Enter your Hallticket number:44555
Dear Student:	'Better luck next time'

