a=float(input("Enter first float:"))
b=float(input("Enter second float:"))
print(a,">", b, ":", a>b)
print(a,"<" , b, ":", a<b)
print(a,">=", b, ":", a>=b)
print(a,"<=" , b, ":", a<=b)
print(a,"==" , b ,":", a==b)
print(a,"!=" , b ,":", a!=b)


#output
Enter first float:78.2
Enter second float:45.2
78.2 > 45.2 : True
78.2 < 45.2 : False
78.2 >= 45.2 : True
78.2 <= 45.2 : False
78.2 == 45.2 : False
78.2 != 45.2 : True

