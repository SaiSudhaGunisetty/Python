class person:
     def Acceptpersoninformation(self):
          self.PersonName=input("Enter person name:")
          self.PersonDOB=input("Enter person DOB:")
          self.PersonAN=int(input("Enter person Aadhar card number:"))
     def Displaypersoninformation(self):
          print("Name\t\t:",self.PersonName)
          print("DOB\t\t:",self.PersonDOB)
          print("Aadhaar Number\t:",self.PersonAN)
class Employee:
     def Acceptemployeeinformation(self):
          self.EmployeeID=input("Enter employee ID:")
          self.EmployeeDept=input("Enter employee Department:")
          self.EmployeeDesg=input("Enter employee Designation:")
          self.EmployeeSalary=float(input("Enter employee Salary:"))
     def Displayemployeeinformation(self):
          print("eID\t\t:",self.EmployeeID)
          print("Department\t:",self.EmployeeDept)
          print("Designation\t:",self.EmployeeDesg)
          print("Salary\t\t:",self.EmployeeSalary)
class Teacher(person, Employee):
     def AcceptTecherinformation(self):
          self.TeacherScl=input("Enter Teachre's School:")
          self.TeacherSub=input("Enter Teacher's Subject:")
          self.TeacherClass=input("Enter Teacher's Class:")
     def DisplayTeacherinformation(self):
          print("School\t\t:",self.TeacherScl)
          print("Subject\t\t:",self.TeacherSub)
          print("Class\t\t:",self.TeacherClass)
t=Teacher()
t.Acceptpersoninformation()
t.Acceptemployeeinformation()
t.AcceptTecherinformation()
t.Displaypersoninformation()
t.Displayemployeeinformation()
t.DisplayTeacherinformation()

          
          
