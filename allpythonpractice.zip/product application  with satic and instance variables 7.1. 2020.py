class Customer:
    CompanyName="Amazon"
    CompanyAddress=" Hyderabad"
    CompanyWebsite="www.amazon.com"    
    def AcceptCustomerData(self):
        self.CustomerFirstname=input("Enter Customer First name:")
        self.CustomerLastname=input("Enter Customer Last name:")
        self.CustomerEmailID=input("Enter Customer EmailID:")
        self.CustomerPhonenumber=float(input("Enter Customer Phonenumber:"))
    def DisplayCustomerInformation(self):                          
        print("*"*20)
        print("CUSTOMER INFORMATION")
        print("*"*20)
        print("Customer Company Name is", Customer.CompanyName)
        print("Customer Company Address is", Customer.CompanyAddress)
        print("Customer Company Website is", Customer.CompanyWebsite)
        print("Customer First name is", self.CustomerFirstname)
        print("Customer Last name is", self.CustomerLastname)
        print("Customer Email ID is", self.CustomerEmailID)
        print("Customer Phone number is", self.CustomerPhonenumber)
        print("*"*20)
c1=Customer()
c1.AcceptCustomerData()
c1.DisplayCustomerInformation()
print("*"*20)
c2=Customer()
c2.AcceptCustomerData()
c2.DisplayCustomerInformation()
print("*"*20)

#output

Enter Customer First name:SaiSudha
Enter Customer Last name:G
Enter Customer EmailID:sudha.saisudha249@gmail.com
Enter Customer Phonenumber:9030251251
********************
CUSTOMER INFORMATION
********************
Customer Company Name is Amazon
Customer Company Address is  Hyderabad
Customer Company Website is www.amazon.com
Customer First name is SaiSudha
Customer Last name is G
Customer Email ID is sudha.saisudha249@gmail.com
Customer Phone number is 9030251251.0
********************
********************
Enter Customer First name:Balakrishna
Enter Customer Last name:N
Enter Customer EmailID:balakrishnanukella@gmail.com
Enter Customer Phonenumber:7799345126
********************
CUSTOMER INFORMATION
********************
Customer Company Name is Amazon
Customer Company Address is  Hyderabad
Customer Company Website is www.amazon.com
Customer First name is Balakrishna
Customer Last name is N
Customer Email ID is balakrishnanukella@gmail.com
Customer Phone number is 7799345126.0
********************
********************

