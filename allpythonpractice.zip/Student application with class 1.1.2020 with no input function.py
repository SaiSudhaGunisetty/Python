class Student:
    Course:"b"
    Institute:"c"
    Address:"d"
    MobileNumber:"123"
    EmailID:"abcd"
def StudentDetailsDisplay():
    print("."*20)
    print("STUDENT INFORMATION")
    print("."*20)
    print("Student Course is:",Student.Course)
    print("Student Institute is:",Student.Institute)
    print("Student Address is:",Student.Address)
    print("Student MobileNumber is:",Student.MobileNumber)
    print("Student Email ID is:",Student.EmailID)
StudentDetailsDisplay()    

   
    
