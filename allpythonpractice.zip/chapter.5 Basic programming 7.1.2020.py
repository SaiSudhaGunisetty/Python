Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=============== RESTART: C:/Users/INDIA/Desktop/core practice.py ===============
S.NO		EName		Salary
-------		---------		-------
1		Lakshmi		1200000
2		Venkat		1500000
>>> 
>>> 
>>> a=5
>>> print("a")
a
>>> print(a)
5
>>> a=5b=6
SyntaxError: invalid syntax
>>> a=5
>>> b=6
>>> print("a+b")
a+b
>>> print("a"+b)
Traceback (most recent call last):
  File "<pyshell#9>", line 1, in <module>
    print("a"+b)
TypeError: can only concatenate str (not "int") to str
>>> a=5
>>> b=6
>>> print(a+b)
11
>>> a=15
>>> b=6
>>> c=a-b
>>> print(c)
9
>>> a=5
>>> b=6
>>> c=a+b
>>> print("Sum is:",c)
Sum is: 11
>>> print(c,"is Your Result")
11 is Your Result
>>> print("Sum",c."is Your Result")
SyntaxError: invalid syntax
>>> print("Sum",c,"is Your Result")
Sum 11 is Your Result
>>> print(a,"and",b,"Sum is",c)
5 and 6 Sum is 11
>>> cost=2500
>>> discount=10
>>> discountAmt=(cost/100)*discount
>>> print(discountAmt)
250.0
>>> a=10
>>> b=20
>>> a=a+b
>>> b=a-b
>>> a=a-b
>>> print(a,"\t",b)
20 	 10
>>> a=20
>>> a="Venk@t Reddy"
>>> print(a)
Venk@t Reddy
>>> a=2
>>> b=a
>>> print(b)
2
>>> n1="Venkat"
>>> n2="Sathya Technology"
>>> fname=n1+"-"+n2
>>> print(fname)
Venkat-Sathya Technology
>>> a="7"
>>> b="9"
>>> c=a+b
>>> print(c)
79
>>> a=7
>>> b=5
>>> b=a//b
>>> a=a//b
>>> print(a,"\t",b)
7 	 1
>>> a=7
>>> b=5
>>> c=a
>>> a=b
>>> b=c
>>> print(a,"\t",b)
5 	 7
>>> n=12
>>> sum=0
>>> r=n%10
>>> r=n//10
>>> sum=sum+r
>>> r=n%10
>>> n=n//10
>>> sum=sum+r
>>> print(n,"\t",sum)
1 	 3
>>> 