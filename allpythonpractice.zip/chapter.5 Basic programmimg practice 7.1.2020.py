Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> n=12
>>> sum=0
>>> r=n%10
>>> n=n//10
>>> sum=sum+r
>>> print(n,"\t",sum)
1 	 2
>>> n=12
>>> sum=0
>>> r=n%10
>>> n=n//10
>>> sum=sum+r
>>> r=n%10
>>> n=n//10
>>> sum=sum+r
>>> print(n,"\t",sum)
0 	 3
>>> c1="Core"
>>> c2="Advanced"
>>> c3="Python"
>>> c4=c1+c2+c3
>>> print(c4)
CoreAdvancedPython
>>> CoreAdvancedPython
Traceback (most recent call last):
  File "<pyshell#20>", line 1, in <module>
    CoreAdvancedPython
NameError: name 'CoreAdvancedPython' is not defined
>>> 
>>> 
>>> a=5
>>> b=7
>>> a,b=b,a
>>> print(a,"\t",b)
7 	 5
>>> p=5
>>> q=3
>>> r=7
>>> print(p,"\t",q,"\t",r)
5 	 3 	 7
>>> p=5
>>> q=3
>>> r=7
>>> print(p,q,r)
5 3 7
>>> p=5
>>> q=3
>>> r=7
>>> print(p,q,r,sep=",")
5,3,7
>>> p=5
>>> q=3
>>> r=7
>>> print(p,q,r,sep="$")
5$3$7
>>> p=5
>>> q=3
>>> r=7
>>> print(p,q,r,sep="-->")
5-->3-->7
>>> p=5
>>> q=3
>>> r=7
>>> print(p,q,r,sep="V")
5V3V7
>>> p=5
>>> q=3
>>> print(p,end="\t")
5	
>>> print(q)
3
>>> print(p)
5
>>> print(q)
3
>>> print(p,end=".")
5.
>>> print(q)
3
>>> a=2.253649
>>> print(a)
2.253649
>>> a=8
>>> print("%d"%a)
8
>>> a=8
>>> b=4
>>> print("%d%d"%(a,b))
84
>>> print("%d\t%d"%(a,b))
8	4
>>> a=41.756
>>> print("%f"%a)
41.756000
>>>  print("%.2f"%a)
 
SyntaxError: unexpected indent
>>> print("%.2f"%a)
41.76
>>>  print("%.4f"%a)
 
SyntaxError: unexpected indent
>>> print("%.4f"%a)
41.7560
>>> print("%d"%a)
41
>>> a=6
>>> print("A value is:{0}".format(a))
A value is:6
>>> a=6
>>> b=3
>>> print("{0}\t{1}",format(a,b))
Traceback (most recent call last):
  File "<pyshell#78>", line 1, in <module>
    print("{0}\t{1}",format(a,b))
TypeError: format() argument 2 must be str, not int
>>> print("{0}\t{1}".format(a,b))
6	3
>>> print("{0}\t{1}".format(b,a))
3	6
>>> a=6.43
>>> print("a={0}".format(a))
a=6.43
>>> 