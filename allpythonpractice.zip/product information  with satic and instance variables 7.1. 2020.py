class Product:
    CompanyName="LG"
    CompanyAddress=" Hyderabad"
    CompanyWebsite="www.lgelectronics.com"    
    def AcceptProductData(self):
        self.ProductName=input("Enter Product name:")
        self.ProductModel=input("Enter Product Model:")
        self.ProductPrice=float(input("Enter Product Price:"))
    def DisplayProductInformation(self):                          
        print("*"*20)
        print("PRODUCT INFORMATION")
        print("*"*20)
        print("Product  Company Name is", Product.CompanyName)
        print("Product Company Address is", Product.CompanyAddress)
        print("Product Company Website is", Product.CompanyWebsite)
        print("Product Name is", self.ProductName)
        print("Product Model is", self.ProductModel)
        print("Product Price is", self.ProductPrice)
        print("*"*20)
p1=Product()
p1.AcceptProductData()
p1.DisplayProductInformation()
print("*"*20)
p2=Product()
p2.AcceptProductData()
p2.DisplayProductInformation()
print("*"*20)


#output

Enter Product name:Refrigerator
Enter Product Model:LG 190L 5 star single door 
Enter Product Price:23987.00
********************
PRODUCT INFORMATION
********************
Product  Company Name is LG
Product Company Address is  Hyderabad
Product Company Website is www.lgelectronics.com
Product Name is Refrigerator
Product Model is LG 190L 5 star single door 
Product Price is 23987.0
********************
********************
Enter Product name:LED TV
Enter Product Model:43 inches attached flexible stand
Enter Product Price:63985.00
********************
PRODUCT INFORMATION
********************
Product  Company Name is LG
Product Company Address is  Hyderabad
Product Company Website is www.lgelectronics.com
Product Name is LED TV
Product Model is 43 inches attached flexible stand
Product Price is 63985.0
********************
********************
>>> 


