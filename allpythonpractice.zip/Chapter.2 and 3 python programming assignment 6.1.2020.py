Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 7/4
1.75
>>> 16//3
5
>>> 9%2
1
>>> 4/7
0.5714285714285714
>>> 3//16
0
>>> 2%9
2
>>> 5.0/2
2.5
>>> 5.0//2
2.0
>>> 
>>> 5+3*2
11
>>> (5+3)*2
16
>>> 12//5*2
4
>>> 6+2*3//2+3
12
>>> 6+4%2*25+5
11
>>> 10-15*3//2*5+4
-96
>>> 3**2
9
>>> 3**2**3
6561
>>> 
>>> print("Venk@t Redde")
Venk@t Redde
>>> 
>>> print("Venk@t Reddy")
Venk@t Reddy
>>> print("Satya Technology")
Satya Technology
>>> print("Python")
Python
>>> print("C.c.Reddy\nPython")
C.c.Reddy
Python
>>> print("Core\tAdvanced")
Core	Advanced
>>> print("Saty@'venkatReddy'")
Saty@'venkatReddy'
>>> print("Satya "Technology"")
SyntaxError: invalid syntax
>>> print("Satya"Technology"")
SyntaxError: invalid syntax
>>> print("Saty@\" Technology\"")
Saty@" Technology"
>>> print("We are C.c Reddi Sir\n\"Python\" Students")
We are C.c Reddi Sir
"Python" Students
>>> print("Satya"+"Technology")
SatyaTechnology
>>> print(5+2)
7
>>> print(12-6)
6
>>> print("12"+"5")
125
>>> print(10/2)
5.0
>>> print("Satya","Technology")
Satya Technology
>>> print("Core","-"," Python")
Core -  Python
>>> print("\n","Satya","-","-"," Tech")

 Satya - -  Tech
>>> print("Python"+3)
Traceback (most recent call last):
  File "<pyshell#38>", line 1, in <module>
    print("Python"+3)
TypeError: can only concatenate str (not "int") to str
>>> 
>>> print(3+3+"Python")
Traceback (most recent call last):
  File "<pyshell#40>", line 1, in <module>
    print(3+3+"Python")
TypeError: unsupported operand type(s) for +: 'int' and 'str'
>>> 
>>> print("7"-2)
Traceback (most recent call last):
  File "<pyshell#42>", line 1, in <module>
    print("7"-2)
TypeError: unsupported operand type(s) for -: 'str' and 'int'
>>> print("7" -2)
Traceback (most recent call last):
  File "<pyshell#43>", line 1, in <module>
    print("7" -2)
TypeError: unsupported operand type(s) for -: 'str' and 'int'
>>> 
>>> print("satya"-"Technology")
Traceback (most recent call last):
  File "<pyshell#45>", line 1, in <module>
    print("satya"-"Technology")
TypeError: unsupported operand type(s) for -: 'str' and 'str'
>>> 
>>> print("Satya\n\tTechnology")
Satya
	Technology
>>> print("Satya\n\t\'Technology")
Satya
	'Technology
>>> print("**Satya Technology**)
      
SyntaxError: EOL while scanning string literal
>>> 
>>> print("**Satya Technology**")
**Satya Technology**
>>> 
>>> print("\n---Python---")

---Python---
>>> print("\t\tBIG BAZAR")
		BIG BAZAR
>>> print("\t\t============")
		============
>>> 