Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
== RESTART: D:\python\GSS python Directory\range with voter ID num 30.12.19.py =
1111
1611
2111
2611
3111
3611
4111
4611
5111
5611
6111
6611
7111
7611
8111
8611
9111
9611
>>> 