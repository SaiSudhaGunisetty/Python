#Employee details program
employeeID= input("Enter employee ID")
employeename= input("Enter employee name")
employeedeparment= input("Enter employee deparment")
employeecompany= input("Enter employee company")
employeedesignation= input("Enter employee designation")
employeesalary= input("Enter employee salry")
print("~"*30)
print("EMPLOYEE DETAILS:")
print("~"*30)
print("employee ID is:", employeeID)
print("employee name is:", employeename)
print("employee deparmentis:", employeedeparment)
print("employee company is:", employeecompany)
print("employee designation is:", employeedesignation)
print("employee salary is:", employeesalary)



