Firstname= input("Enter your First name: ")
Lastname= input("Enter your Last name: ")
Mobilenumber= input("Enter your Mobile number: ")
EmailID= input("Enter your Email ID: ")
print("CUSTOMERINFORMATION")
print("."*40)
print("Dear customer your First name is: Firstname")
print("Dear customer your Last name is: Lastname")
print("Dear customer your Mobile number is: Mobilenumber")
print("Dear customer your Email ID is: EmailID")
print("."*40)


