Passportnumbers=range(12345,56790)
Visanumbers=range(1122,2234)
PN=int(input("Enter your Passport number:"))
VN=int(input("Enter your Visa number:"))
if PN in Passportnumbers and VN in Visanumbers:
       print("Dear passanger Happy Journey")
else:
     print("Dear passanger enter valid details:")


#output

Enter your Passport number:12345
Enter your Visa number:2233
Dear passanger Happy Journey
