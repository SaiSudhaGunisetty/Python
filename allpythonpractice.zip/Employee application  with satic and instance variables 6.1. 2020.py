class Employee:
    CompanyName="Tech mahendra"
    CompanyAddress="Ameerpet, Hyderabad"
    CompanyWebsite="www.techmahendra.com"    
    def AcceptEmployeeData(self):
        self.EmployeeID=input("Enter Employee ID:")
        self.EmployeeName=input("Enter Employee Name:")
        self.EmployeeAddress=input("Enter Employee Address:")
        self.EmployeeDepartment =input("Enter Employee Department:")
        self.EmployeeDesignation=input("Enter Employee Designation:")
        self.EmployeeSalary=float(input("Enter Employee Salary:"))
    def DisplayEmployeeInformation(self):                          
        print("*"*20)
        print("EMPLOYEE INFORMATION")
        print("*"*20)
        print("Employee Company Name is", Employee.CompanyName)
        print("Employee Company Address is", Employee.CompanyAddress)
        print("Employee Company Website is", Employee.CompanyWebsite)
        print("Employee ID is", self.EmployeeID)
        print("Employee Name is", self.EmployeeName)
        print("Employee Address is", self.EmployeeAddress)
        print("Employee Deparment is", self.EmployeeDepartment)
        print("Employee Designation is", self.EmployeeDesignation)
        print("Employee Salary is", self.EmployeeSalary)
        print("*"*20)
e1=Employee()
e1.AcceptEmployeeData()
e1.DisplayEmployeeInformation()
print("*"*20)
e2=Employee()
e2.AcceptEmployeeData()
e2.DisplayEmployeeInformation()
print("*"*20)
e3=Employee()
e3.AcceptEmployeeData()
e3.DisplayEmployeeInformation()
print("*"*20)
e4=Employee()
e4.AcceptEmployeeData()
e4.DisplayEmployeeInformation()


#output:

Enter Employee ID:E1122
Enter Employee Name:G.SaiSudha
Enter Employee Address:Hyderabad
Enter Employee Department:IT
Enter Employee Designation:Python Developer
Enter Employee Salary:125000
********************
EMPLOYEE INFORMATION
********************
Employee Company Name is Tech mahendra
Employee Company Address is Ameerpet, Hyderabad
Employee Company Website is www.techmahendra.com
Employee ID is E1122
Employee Name is G.SaiSudha
Employee Address is Hyderabad
Employee Deparment is IT
Employee Designation is Python Developer
Employee Salary is 125000.0
********************
********************
Enter Employee ID:E2233
Enter Employee Name:Teja
Enter Employee Address:Ameerpet
Enter Employee Department:IT
Enter Employee Designation:Python developer
Enter Employee Salary:100000
********************
EMPLOYEE INFORMATION
********************
Employee Company Name is Tech mahendra
Employee Company Address is Ameerpet, Hyderabad
Employee Company Website is www.techmahendra.com
Employee ID is E2233
Employee Name is Teja
Employee Address is Ameerpet
Employee Deparment is IT
Employee Designation is Python developer
Employee Salary is 100000.0
********************
********************
Enter Employee ID:E3344
Enter Employee Name:Harini
Enter Employee Address:Begumpet
Enter Employee Department:IT
Enter Employee Designation:Python Developer
Enter Employee Salary:80000
********************
EMPLOYEE INFORMATION
********************
Employee Company Name is Tech mahendra
Employee Company Address is Ameerpet, Hyderabad
Employee Company Website is www.techmahendra.com
Employee ID is E3344
Employee Name is Harini
Employee Address is Begumpet
Employee Deparment is IT
Employee Designation is Python Developer
Employee Salary is 80000.0
********************
********************
Enter Employee ID:4455
Enter Employee Name:Lakshmi
Enter Employee Address:SR Nagar
Enter Employee Department:IT
Enter Employee Designation:Python Developer
Enter Employee Salary:75000
********************
EMPLOYEE INFORMATION
********************
Employee Company Name is Tech mahendra
Employee Company Address is Ameerpet, Hyderabad
Employee Company Website is www.techmahendra.com
Employee ID is 4455
Employee Name is Lakshmi
Employee Address is SR Nagar
Employee Deparment is IT
Employee Designation is Python Developer
Employee Salary is 75000.0
********************
>>> 

        
    
