marks=int(input("Enter your marks in Python subject:"))
if marks>=100:
     print("Please enter marks less than 100, because MAXIMUM MARKS are 100")
elif marks==100:
     print("Grade is:A+")
elif marks>=90:
      print("Grade is:A")
elif marks>=80:
      print("Grade is:B+")
elif marks>=70:
      print("Grade is:B")
elif marks>=60:
      print("Grade is:C+")
elif marks>=50:
      print("Grade is:C")
elif marks>=40:
      print("JUST PASS")
else:
      print("FAIL")


#output:
Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
================ RESTART: C:/Users/INDIA/Desktop/if..elif..else.py ===============
Enter your marks in Python subject:123
Please enter marks less than 100, because MAXIMUM MARKS are 100
>>> 
================ RESTART: C:/Users/INDIA/Desktop/if..elif..else.py ===============
Enter your marks in Python subject:100
Please enter marks less than 100, because MAXIMUM MARKS are 100
>>> 
================ RESTART: C:/Users/INDIA/Desktop/if..elif..else.py ===============
Enter your marks in Python subject:98
Grade is:A
>>> 
================ RESTART: C:/Users/INDIA/Desktop/if..elif..else.py ===============
Enter your marks in Python subject:88
Grade is:B+
>>> 
================ RESTART: C:/Users/INDIA/Desktop/if..elif..else.py ===============
Enter your marks in Python subject:78
Grade is:B
>>> 
================ RESTART: C:/Users/INDIA/Desktop/if..elif..else.py ===============
Enter your marks in Python subject:68
Grade is:C+
>>> 
================ RESTART: C:/Users/INDIA/Desktop/if..elif..else.py ===============
Enter your marks in Python subject:58
Grade is:C
>>> 
================ RESTART: C:/Users/INDIA/Desktop/if..elif..else.py ===============
Enter your marks in Python subject:48
JUST PASS
>>> 
================ RESTART: C:/Users/INDIA/Desktop/if..elif..else.py ===============
Enter your marks in Python subject:25
FAIL
>>> 
            
