Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
== RESTART: D:\python\GSS python Directory\typecasting with float 23.12.19.py ==
Enter first float value= 10.2
Enter second float value= 5.3
Addition: 15.5
Subtraction: 4.8999999999999995
Multiplication: 54.059999999999995
Division: 1.9245283018867925
Modulus 1.0
>>> 