class Vehicle:
     def AcceptVehicleinformation(self):
          self.VehicleModel=input("Ente Vehicle Model:")
          self.VehicleCompany=input("Enter Vehicle Company:")
          self.VehicleFueltype=input("Enter Vehicle fuel type:")
     def DisplayVehicleinformation(self):
          print("Model\t\t:", self.VehicleModel)
          print("Company\t\t:", self.VehicleCompany)
          print("Fueltype\t\t:", self.VehicleFueltype)
class Bike(Vehicle):
     def AcceptBikeinformation(self):
          self.BikeHeight=float(input("Enter Bike Height:"))
          self.BikeWeight=float(input("Enter Bike Weight:"))
          self.BikeSeatingCapacity=int(input("Enter Bike seating capacity:"))
          self.BikePrice=float(input("Enter Bike Price:"))
     def DisplayBikeinformation(self):
          print("Height\t\t:", self.BikeHeight)
          print("Weight\t\t:", self.BikeWeight)
          print("Seating capacity\t:", self.BikeSeatingCapacity)
          print("Price\t\t:", self.BikePrice)
class Bus(Vehicle):
     def AcceptBusinformation(self):
          self.BusHeight=float(input("Enter Bus Height:"))
          self.BusWeight=float(input("Enter Bus Weight:"))
          self.BusSeatingCapacity=int(input("Enter Bus seating capacity:"))
          self.BusPrice=float(input("Enter Bus Price:"))
     def DisplayBusinformation(self):
          print("Height\t\t:", self.BusHeight)
          print("Weight\t\t:", self.BusWeight)
          print("Seating capacity\t:", self.BusSeatingCapacity)
          print("Price\t\t:", self.BusPrice)
class Car(Vehicle):
     def AcceptCarinformation(self):
          self.CarHeight=float(input("Enter Car Height:"))
          self.CarWeight=float(input("Enter Car Weight:"))
          self.CarSeatingCapacity=int(input("Enter Car seating capacity:"))
          self.CarPrice=float(input("Enter Car Price:"))
     def DisplayCarinformation(self):
          print("Height\t\t:", self.CarHeight)
          print("Weight\t\t:", self.CarWeight)
          print("Seating capacity\t:", self.CarSeatingCapacity)
          print("Price\t\t:", self.CarPrice)
b1=Bike()
b2=Bus()
c=Car()
print("~"*50)
b1.AcceptVehicleinformation()
b1.AcceptBikeinformation()
print("~"*50)
print("Bike information:")
print("~"*50)
b1.DisplayVehicleinformation()
b1.DisplayBikeinformation()
print("~"*50)
b2.AcceptVehicleinformation()
b2.AcceptBusinformation()
print("~"*50)
print("Bus information:")
print("~"*50)
b2.DisplayVehicleinformation()
b2.DisplayBusinformation()
print("~"*50)
c.AcceptVehicleinformation()
c.AcceptCarinformation()
print("~"*50)
print("Car information:")
print("~"*50)
c.DisplayVehicleinformation()
c.DisplayCarinformation()
print("~"*50)

#OUTPUT:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Ente Vehicle Model:5G
Enter Vehicle Company:HONDA ACTIVA
Enter Vehicle fuel type:PETROL
Enter Bike Height:3.2
Enter Bike Weight:85
Enter Bike seating capacity:2
Enter Bike Price:85214
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Bike information:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Model		: 5G
Company		: HONDA ACTIVA
Fueltype		: PETROL
Height		: 3.2
Weight		: 85.0
Seating capacity	: 2
Price		: 85214.0
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Ente Vehicle Model:SLEEPER
Enter Vehicle Company:OLVO
Enter Vehicle fuel type:DIESEL
Enter Bus Height:8
Enter Bus Weight:500
Enter Bus seating capacity:100
Enter Bus Price:159753
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Bus information:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Model		: SLEEPER
Company		: OLVO
Fueltype		: DIESEL
Height		: 8.0
Weight		: 500.0
Seating capacity	: 100
Price		: 159753.0
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Ente Vehicle Model:SWIFT
Enter Vehicle Company:MARUTHI
Enter Vehicle fuel type:PETROL
Enter Car Height:4.5
Enter Car Weight:500
Enter Car seating capacity:6
Enter Car Price:753951
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Car information:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Model		: SWIFT
Company		: MARUTHI
Fueltype		: PETROL
Height		: 4.5
Weight		: 500.0
Seating capacity	: 6
Price		: 753951.0
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~




         
                
     
