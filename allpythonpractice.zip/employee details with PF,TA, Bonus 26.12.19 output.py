Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: D:\python\GSS python Directory\employee details with PF,TA, Bonus 26.12.19.py
Enter employee ID:E123
Enter employee name:Balakrishna
Enter employee designation:Junior manager
Enter employee deparment:Validation
Enter employee salary:56300
Total employee salary: 79745.0
>>> 