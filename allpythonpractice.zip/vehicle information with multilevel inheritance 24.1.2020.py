class Vehicle:
     def AcceptVehicleinformation(self):
          self.VehicleModel=input("Ente Vehicle Model:")
          self.VehicleCompany=input("Enter Vehicle Company:")
          self.VehicleFueltype=input("Enter Vehicle fuel type:")
     def DisplayVehicleinformation(self):
          print("Model\t\t:", self.VehicleModel)
          print("Company\t\t:", self.VehicleCompany)
          print("Fueltype\t\t:", self.VehicleFueltype)
class RegisteredVehicle(Vehicle):
     def AcceptRegisteredVehicleinformation(self):
          self.RVName=input("Enter Registered Vehicle Name:")
          self.RVOName=input("Enter Registered Vehicle Owner's Name:")
          self.RVRN=int(input("Enter Registered Vehicle Registration Number:"))
          self.RVRDate=input("Enter Registred Vehicle Registration Date:")
          self.RVPlace=input("Enter Registered Vehicle Registration place:")
     def DisplayRegisteredVehicleinformation(self):
          print("Name \t\t:", self.RVName)
          print("Owner's Name\t:", self.RVOName)
          print("Registration No\t:", self.RVRN)
          print("Date of Registration:", self.RVRDate)
          print("Place of Registration:", self.RVPlace)
class Car(RegisteredVehicle):
     def AcceptCarinformation(self):
          self.CarHeight=float(input("Enter Car Height:"))
          self.CarWeight=float(input("Enter Car Weight:"))
          self.CarSeatingCapacity=int(input("Enter Car seating capacity:"))
          self.CarPrice=float(input("Enter Car Price:"))
     def DisplayCarinformation(self):
          print("Height\t\t:", self.CarHeight)
          print("Weight\t\t:", self.CarWeight)
          print("Seating capacity\t:", self.CarSeatingCapacity)
          print("Price\t\t:", self.CarPrice)
c=Car()
c.AcceptVehicleinformation()
c.AcceptRegisteredVehicleinformation()
c.AcceptCarinformation()
c.DisplayVehicleinformation()
c.DisplayRegisteredVehicleinformation()
c.DisplayCarinformation()

#output
Ente Vehicle Model:Maruthi STZ
Enter Vehicle Company:Maruthi Motors
Enter Vehicle fuel type:Petrol
Enter Registered Vehicle Name:Car
Enter Registered Vehicle Owner's Name:Sai Sudha.G
Enter Registered Vehicle Registration Number:71919
Enter Registred Vehicle Registration Date:13/9/2020
Enter Registered Vehicle Registration place:Hyderabad
Enter Car Height:6.9
Enter Car Weight:256.9
Enter Car seating capacity:6
Enter Car Price:654999
Model		: Maruthi STZ
Company		: Maruthi Motors
Fueltype		: Petrol
Name 		: Car
Owner's Name	: Sai Sudha.G
Registration No	: 71919
Date of Registration: 13/9/2020
Place of Registration: Hyderabad
Height		: 6.9
Weight		: 256.9
Seating capacity	: 6
Price		: 654999.0
          
                
     
