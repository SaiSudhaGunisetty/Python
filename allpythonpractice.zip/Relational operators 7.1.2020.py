a=int(input("Enter first integer:"))
b=int(input("Enter second integer:"))
print(a,">", b, ":", a>b)
print(a,"<" , b, ":", a<b)
print(a,">=", b, ":", a>=b)
print(a,"<=" , b, ":", a<=b)
print(a,"==" , b ,":", a==b)
print(a,"!=" , b ,":", a!=b)

#output

Enter first integer:124
Enter second integer:86
124 > 86 : True
124 < 86 : False
124 >= 86 : True
124 <= 86 : False
124 == 86 : False
124 != 86 : True
