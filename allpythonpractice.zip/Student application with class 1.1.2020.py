class Student:
    StudentName:"sai"
    StudentCourse:"python"
    StudentInstitute:"satya"
    StudentAddress:"bee"
    StudentMobileNumber:"8121310114"
    StudentEmailID:"sai@gmail.com"
def StudentInformationDisplay():
    print("."*20)
    print("STUDENT INFORMATION")
    print("."*20)
    print("Student Name is:", Student.StudentName)
    print("Student Course is:", Student.StudentCourse)
    print("Student Institute is:", Student.StudentInstitute)
    print("Student Address is:", Student.StudentAddress)
    print("Student MobileNumber is:", Student.StudentMobileNumber)
    print("Student Email ID is:", Student.StudentEmailID)
StudentInformationDisplay()   
    
