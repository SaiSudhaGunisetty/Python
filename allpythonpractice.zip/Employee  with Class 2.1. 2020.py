class Employee:
    ID="E1919"
    Name="G. Sai Sudha"
    Department="IT"
    Designation="Python Developer"
    Salary=80000
    Bonus=5000
    IncomeTax=80000*(4/100)
    DA=2500
    Homeloan=5000
    TotalSalary=Salary+Bonus-IncomeTax+DA-Homeloan
    def Employeeinformationdisplay():
        print("~"*20)
        print("Employee Infromation")
        print("~"*20)
        print("Employee ID is", Employee.ID)
        print("Employee Name is", Employee.Name)
        print("Employee Department is", Employee.Department)
        print("Employee Designation is", Employee.Designation)
    def EmployeeSalaryCalculation():
        print("Employee Total Salary is", Employee.TotalSalary)
Employee.Employeeinformationdisplay()
Employee.EmployeeSalaryCalculation()
