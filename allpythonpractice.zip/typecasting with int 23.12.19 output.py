Python 3.8.1 (tags/v3.8.1:1b293b6, Dec 18 2019, 23:11:46) [MSC v.1916 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
=== RESTART: D:\python\GSS python Directory\typecasting with int 23.12.19.py ===
Enter first integer= 12
Enter second integer= 8
Addition: 20
Subtraction: 4
Multiplication: 96
Division: 1.5
Modulus 1
exponential 429981696
>>> 